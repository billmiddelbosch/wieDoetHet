var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// wiedoethet-claims/index.js
var index_exports = {};
__export(index_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(index_exports);
var import_node_crypto2 = require("node:crypto");

// shared/http.js
var CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS"
};
function ok(data) {
  return { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify(data) };
}
function created(data) {
  return { statusCode: 201, headers: CORS_HEADERS, body: JSON.stringify(data) };
}
function noContent() {
  return { statusCode: 204, headers: CORS_HEADERS, body: "" };
}
function unauthorized(message = "Niet ingelogd") {
  return { statusCode: 401, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function forbidden(message = "Geen toegang") {
  return { statusCode: 403, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function notFound(message = "Niet gevonden") {
  return { statusCode: 404, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function conflict(message = "Conflict") {
  return { statusCode: 409, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function serverError(err) {
  console.error(err);
  return {
    statusCode: 500,
    headers: CORS_HEADERS,
    body: JSON.stringify({ message: "Interne serverfout" })
  };
}
function parseBody(event) {
  try {
    return event.body ? JSON.parse(event.body) : {};
  } catch {
    return {};
  }
}
function extractBearer(event) {
  const auth = event.headers?.Authorization ?? event.headers?.authorization ?? "";
  const token = auth.replace(/^Bearer\s+/i, "");
  return token || null;
}

// shared/jwt.js
var import_node_crypto = require("node:crypto");
var SECRET = process.env.JWT_SECRET;
var EXPIRES_SEC = Number(process.env.JWT_EXPIRES_SEC ?? 2592e3);
function b64urlDecode(str) {
  return Buffer.from(str, "base64url").toString("utf8");
}
function sign(header, body) {
  return (0, import_node_crypto.createHmac)("sha256", SECRET).update(`${header}.${body}`).digest("base64url");
}
function verifyJwt(token) {
  if (!SECRET) throw new Error("JWT_SECRET env var is not set");
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Malformed token");
  const [header, body, sig] = parts;
  const expected = sign(header, body);
  if (sig.length !== expected.length) throw new Error("Invalid signature");
  let diff = 0;
  for (let i = 0; i < sig.length; i++) diff |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
  if (diff !== 0) throw new Error("Invalid signature");
  const payload = JSON.parse(b64urlDecode(body));
  if (payload.exp < Math.floor(Date.now() / 1e3)) throw new Error("Token expired");
  return payload;
}

// shared/db.js
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var client = new import_client_dynamodb.DynamoDBClient({});
var ddb = import_lib_dynamodb.DynamoDBDocumentClient.from(client, {
  marshallOptions: { removeUndefinedValues: true }
});
var table = () => process.env.TABLE_NAME ?? "wdh-main";
async function getItem(pk, sk) {
  const { Item } = await ddb.send(new import_lib_dynamodb.GetCommand({ TableName: table(), Key: { PK: pk, SK: sk } }));
  return Item ?? null;
}
async function putItem(item) {
  await ddb.send(new import_lib_dynamodb.PutCommand({ TableName: table(), Item: item }));
  return item;
}
async function deleteItem(pk, sk) {
  await ddb.send(new import_lib_dynamodb.DeleteCommand({ TableName: table(), Key: { PK: pk, SK: sk } }));
}
async function queryByPk(pk, skPrefix = null, indexName = null) {
  const params = {
    TableName: table(),
    KeyConditionExpression: skPrefix ? "PK = :pk AND begins_with(SK, :prefix)" : "PK = :pk",
    ExpressionAttributeValues: skPrefix ? { ":pk": pk, ":prefix": skPrefix } : { ":pk": pk }
  };
  if (indexName) {
    params.IndexName = indexName;
    params.KeyConditionExpression = params.KeyConditionExpression.replace(/\bPK\b/g, indexName === "GSI1" ? "GSI1PK" : "GSI2PK").replace(/\bSK\b/g, indexName === "GSI1" ? "GSI1SK" : "GSI2SK");
  }
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}
async function queryGsi1(gsi1pk, gsi1skPrefix = null) {
  const params = {
    TableName: table(),
    IndexName: "GSI1",
    KeyConditionExpression: gsi1skPrefix ? "GSI1PK = :pk AND begins_with(GSI1SK, :prefix)" : "GSI1PK = :pk",
    ExpressionAttributeValues: gsi1skPrefix ? { ":pk": gsi1pk, ":prefix": gsi1skPrefix } : { ":pk": gsi1pk }
  };
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}

// wiedoethet-claims/index.js
async function claimTask(event) {
  const { groupId, taskId } = event.pathParameters ?? {};
  const jwtPayload = tryAuth(event);
  const body = parseBody(event);
  if (!jwtPayload && (!body.anonymousName || !body.sessionId)) {
    return unauthorized("Naam en sessie-ID zijn verplicht voor anonieme claims");
  }
  const taskItems = await queryByPk(`GROUP#${groupId}`, "TASK#");
  const task = taskItems.find((t) => t.id === taskId);
  if (!task) return notFound("Taak niet gevonden");
  const existingClaims = await queryByPk(`TASK#${taskId}`, "CLAIM#");
  if (existingClaims.length >= (task.maxClaims ?? 1)) return conflict("Taak is al vol");
  const alreadyClaimed = existingClaims.some(
    (c) => jwtPayload ? c.userId === jwtPayload.sub : c.sessionId === body.sessionId
  );
  if (alreadyClaimed) return conflict("Je hebt deze taak al geclaimd");
  const id = (0, import_node_crypto2.randomUUID)();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const claim = {
    PK: `TASK#${taskId}`,
    SK: `CLAIM#${id}`,
    GSI1PK: `GCLAIM#${groupId}`,
    GSI1SK: now,
    id,
    groupId,
    taskId,
    userId: jwtPayload?.sub ?? null,
    anonymousName: jwtPayload ? null : body.anonymousName,
    sessionId: jwtPayload ? null : body.sessionId,
    claimedAt: now
  };
  await putItem(claim);
  return created(stripKeys(claim));
}
async function unclaimTask(event) {
  const { groupId, taskId } = event.pathParameters ?? {};
  const jwtPayload = tryAuth(event);
  const body = parseBody(event);
  const claims = await queryByPk(`TASK#${taskId}`, "CLAIM#");
  const claim = claims.find(
    (c) => jwtPayload ? c.userId === jwtPayload.sub : c.sessionId === body.sessionId
  );
  if (!claim) return notFound("Claim niet gevonden");
  await deleteItem(claim.PK, claim.SK);
  return noContent();
}
async function listClaims(event) {
  const { groupId } = event.pathParameters ?? {};
  const jwtPayload = tryAuth(event);
  const group = await getItem(`GROUP#${groupId}`, "METADATA");
  if (!group) return notFound("Groep niet gevonden");
  const vis = group.scorecardVisibility;
  if (vis === "initiator" && jwtPayload?.sub !== group.initiatorId) return forbidden("Alleen de initiator kan het scorebord zien");
  if (vis === "selected") {
    const allowed = group.scorecardViewerIds ?? [];
    if (!jwtPayload || !allowed.includes(jwtPayload.sub) && jwtPayload.sub !== group.initiatorId) {
      return forbidden("Je hebt geen toegang tot het scorebord");
    }
  }
  const claims = await queryGsi1(`GCLAIM#${groupId}`);
  const taskIds = [...new Set(claims.map((c) => c.taskId))];
  const userIds = [...new Set(claims.map((c) => c.userId).filter(Boolean))];
  const [taskItems, userRecords] = await Promise.all([
    queryByPk(`GROUP#${groupId}`, "TASK#"),
    Promise.all(userIds.map((uid) => getItem(`USER#${uid}`, "PROFILE")))
  ]);
  const taskMap = Object.fromEntries(taskItems.map((t) => [t.id, t.title]));
  const userMap = Object.fromEntries(
    userRecords.filter(Boolean).map((u) => [u.id, u.name])
  );
  const enriched = claims.map((c) => ({
    ...stripKeys(c),
    taskTitle: taskMap[c.taskId] ?? "?",
    claimedByName: c.userId ? userMap[c.userId] ?? "Onbekend" : c.anonymousName ?? "Anoniem"
  }));
  return ok(enriched);
}
function stripKeys(item) {
  const { PK, SK, GSI1PK, GSI1SK, ...rest } = item;
  return rest;
}
function tryAuth(event) {
  const token = extractBearer(event);
  if (!token) return null;
  try {
    return verifyJwt(token);
  } catch {
    return null;
  }
}
var handler = async (event) => {
  process.env.TABLE_NAME = event.stageVariables?.tableName ?? process.env.TABLE_NAME ?? "wdh-main";
  try {
    const method = event.httpMethod;
    const path = event.path?.replace(/\/$/, "");
    if (method === "OPTIONS") return { statusCode: 204, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type,Authorization", "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS" }, body: "" };
    if (method === "POST" && /^\/groups\/[^/]+\/tasks\/[^/]+\/claim$/.test(path)) return await claimTask(event);
    if (method === "DELETE" && /^\/groups\/[^/]+\/tasks\/[^/]+\/claim$/.test(path)) return await unclaimTask(event);
    if (method === "GET" && /^\/groups\/[^/]+\/claims$/.test(path)) return await listClaims(event);
    return { statusCode: 404, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: "Route niet gevonden" }) };
  } catch (err) {
    return serverError(err);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
