var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// wiedoethet-admin/index.js
var index_exports = {};
__export(index_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(index_exports);

// shared/http.js
var CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS"
};
function ok(data) {
  return { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify(data) };
}
function badRequest(message = "Ongeldig verzoek") {
  return { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function unauthorized(message = "Niet ingelogd") {
  return { statusCode: 401, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function forbidden(message = "Geen toegang") {
  return { statusCode: 403, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function notFound(message = "Niet gevonden") {
  return { statusCode: 404, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function badGateway(message = "Externe dienst niet bereikbaar") {
  return { statusCode: 502, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function serverError(err) {
  console.error(err);
  return {
    statusCode: 500,
    headers: CORS_HEADERS,
    body: JSON.stringify({ message: "Interne serverfout" })
  };
}
function parseBody(event) {
  try {
    return event.body ? JSON.parse(event.body) : {};
  } catch {
    return {};
  }
}
function extractBearer(event) {
  const auth = event.headers?.Authorization ?? event.headers?.authorization ?? "";
  const token = auth.replace(/^Bearer\s+/i, "");
  return token || null;
}

// shared/jwt.js
var import_node_crypto = require("node:crypto");
var SECRET = process.env.JWT_SECRET;
var EXPIRES_SEC = Number(process.env.JWT_EXPIRES_SEC ?? 2592e3);
function b64urlDecode(str) {
  return Buffer.from(str, "base64url").toString("utf8");
}
function sign(header, body) {
  return (0, import_node_crypto.createHmac)("sha256", SECRET).update(`${header}.${body}`).digest("base64url");
}
function verifyJwt(token) {
  if (!SECRET) throw new Error("JWT_SECRET env var is not set");
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Malformed token");
  const [header, body, sig] = parts;
  const expected = sign(header, body);
  if (sig.length !== expected.length) throw new Error("Invalid signature");
  let diff = 0;
  for (let i = 0; i < sig.length; i++) diff |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
  if (diff !== 0) throw new Error("Invalid signature");
  const payload = JSON.parse(b64urlDecode(body));
  if (payload.exp < Math.floor(Date.now() / 1e3)) throw new Error("Token expired");
  return payload;
}

// shared/db.js
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var client = new import_client_dynamodb.DynamoDBClient({});
var ddb = import_lib_dynamodb.DynamoDBDocumentClient.from(client, {
  marshallOptions: { removeUndefinedValues: true }
});
var table = () => process.env.TABLE_NAME ?? "wdh-main";
var keys = {
  user: (id) => ({ PK: `USER#${id}`, SK: "PROFILE" }),
  userByEmail: (email) => ({ GSI1PK: `EMAIL#${email}`, GSI1SK: "USER" }),
  group: (id) => ({ PK: `GROUP#${id}`, SK: "METADATA" }),
  groupByShareToken: (token) => ({ GSI1PK: `SHARE#${token}`, GSI1SK: "GROUP" }),
  groupsByInitiator: (userId) => ({ GSI2PK: `INITIATOR#${userId}`, GSI2SK: `GROUP#` }),
  task: (groupId, order, taskId) => ({
    PK: `GROUP#${groupId}`,
    SK: `TASK#${String(order).padStart(5, "0")}#${taskId}`
  }),
  tasksInGroup: (groupId) => ({ PK: `GROUP#${groupId}`, SKPrefix: "TASK#" }),
  claim: (taskId, claimId) => ({ PK: `TASK#${taskId}`, SK: `CLAIM#${claimId}` }),
  claimsOnTask: (taskId) => ({ PK: `TASK#${taskId}`, SKPrefix: "CLAIM#" }),
  claimsByGroup: (groupId) => ({ GSI1PK: `GCLAIM#${groupId}` }),
  // GSI3 — Admin Section (wiedoethet-admin): "list all users/groups" without a table Scan.
  userGsi3: (createdAt, id) => ({ GSI3PK: "USER", GSI3SK: `${createdAt}#${id}` }),
  groupGsi3: (createdAt, id) => ({ GSI3PK: "GROUP", GSI3SK: `${createdAt}#${id}` }),
  // Mail automation. scopeId = groupId for group-scoped templates, '-' for user-scoped ones.
  mailTemplate: (templateId) => ({ PK: `MAILTPL#${templateId}`, SK: "CONFIG" }),
  mailLog: (userId, templateId, scopeId) => ({ PK: `USER#${userId}`, SK: `MAIL#${templateId}#${scopeId}` }),
  mailLogGsi3: (createdAt, userId, templateId) => ({ GSI3PK: "MAILLOG", GSI3SK: `${createdAt}#${userId}#${templateId}` }),
  mailState: () => ({ PK: "MAILSTATE#lifecycle", SK: "LASTRUN" }),
  mailMaster: () => ({ PK: "MAILSTATE#lifecycle", SK: "MASTER" })
};
async function getItem(pk, sk) {
  const { Item } = await ddb.send(new import_lib_dynamodb.GetCommand({ TableName: table(), Key: { PK: pk, SK: sk } }));
  return Item ?? null;
}
async function updateItem(pk, sk, updates) {
  const expressions = [];
  const names = {};
  const values = {};
  for (const [key, val] of Object.entries(updates)) {
    expressions.push(`#${key} = :${key}`);
    names[`#${key}`] = key;
    values[`:${key}`] = val;
  }
  await ddb.send(new import_lib_dynamodb.UpdateCommand({
    TableName: table(),
    Key: { PK: pk, SK: sk },
    UpdateExpression: `SET ${expressions.join(", ")}`,
    ExpressionAttributeNames: names,
    ExpressionAttributeValues: values
  }));
}
var LAST_SEEN_THROTTLE_MS = 24 * 60 * 60 * 1e3;
async function queryByPk(pk, skPrefix = null, indexName = null) {
  const params = {
    TableName: table(),
    KeyConditionExpression: skPrefix ? "PK = :pk AND begins_with(SK, :prefix)" : "PK = :pk",
    ExpressionAttributeValues: skPrefix ? { ":pk": pk, ":prefix": skPrefix } : { ":pk": pk }
  };
  if (indexName) {
    params.IndexName = indexName;
    params.KeyConditionExpression = params.KeyConditionExpression.replace(/\bPK\b/g, indexName === "GSI1" ? "GSI1PK" : "GSI2PK").replace(/\bSK\b/g, indexName === "GSI1" ? "GSI1SK" : "GSI2SK");
  }
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}
async function queryGsi1(gsi1pk, gsi1skPrefix = null) {
  const params = {
    TableName: table(),
    IndexName: "GSI1",
    KeyConditionExpression: gsi1skPrefix ? "GSI1PK = :pk AND begins_with(GSI1SK, :prefix)" : "GSI1PK = :pk",
    ExpressionAttributeValues: gsi1skPrefix ? { ":pk": gsi1pk, ":prefix": gsi1skPrefix } : { ":pk": gsi1pk }
  };
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}
async function queryGsi2(gsi2pk, gsi2skPrefix = null) {
  const params = {
    TableName: table(),
    IndexName: "GSI2",
    KeyConditionExpression: gsi2skPrefix ? "GSI2PK = :pk AND begins_with(GSI2SK, :prefix)" : "GSI2PK = :pk",
    ExpressionAttributeValues: gsi2skPrefix ? { ":pk": gsi2pk, ":prefix": gsi2skPrefix } : { ":pk": gsi2pk }
  };
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}
async function queryGsi3(gsi3pk, {
  skGte,
  limit,
  exclusiveStartKey,
  scanIndexForward = true,
  filterExpression,
  expressionAttributeNames,
  expressionAttributeValues,
  select
} = {}) {
  const names = { ...expressionAttributeNames };
  const values = { ":pk": gsi3pk, ...expressionAttributeValues };
  let keyCondition = "GSI3PK = :pk";
  if (skGte !== void 0) {
    keyCondition += " AND GSI3SK >= :skGte";
    values[":skGte"] = skGte;
  }
  const params = {
    TableName: table(),
    IndexName: "GSI3",
    KeyConditionExpression: keyCondition,
    ExpressionAttributeValues: values,
    ScanIndexForward: scanIndexForward
  };
  if (Object.keys(names).length) params.ExpressionAttributeNames = names;
  if (limit !== void 0) params.Limit = limit;
  if (exclusiveStartKey !== void 0) params.ExclusiveStartKey = exclusiveStartKey;
  if (filterExpression) params.FilterExpression = filterExpression;
  if (select) params.Select = select;
  const { Items, LastEvaluatedKey, Count } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return { items: Items ?? [], lastEvaluatedKey: LastEvaluatedKey ?? null, count: Count };
}

// shared/ses.js
var import_client_ses = require("@aws-sdk/client-ses");
var client2 = new import_client_ses.SESClient({});
async function sendMail({ to, subject, html, replyTo }) {
  const fromEmail = process.env.SES_FROM_EMAIL;
  if (!fromEmail) throw new Error("SES_FROM_EMAIL env var is not set");
  const replyToEmail = replyTo ?? process.env.SES_REPLY_TO_EMAIL;
  if (!replyToEmail) throw new Error("SES_REPLY_TO_EMAIL env var is not set");
  const result = await client2.send(new import_client_ses.SendEmailCommand({
    Source: fromEmail,
    Destination: { ToAddresses: [to] },
    ReplyToAddresses: [replyToEmail],
    Message: {
      Subject: { Data: subject, Charset: "UTF-8" },
      Body: { Html: { Data: html, Charset: "UTF-8" } }
    }
  }));
  return { messageId: result?.MessageId ?? null };
}

// shared/email-template.js
var OPT_OUT_PROCESSING_TEXT = "binnen 2 werkdagen";
var escapeHtml = (value) => String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
function footerHtml(replyToEmail) {
  const safeEmail = escapeHtml(replyToEmail);
  const link2 = `<a href="mailto:${safeEmail}" style="color:#2080b8;text-decoration:underline;">${safeEmail}</a>`;
  return `<div style="margin-top:32px;padding-top:24px;border-top:1px solid #e2e8f0;">
<p style="margin:0 0 4px;font-size:14px;line-height:1.6;color:#1e293b;font-weight:600;">Idee\xEBn om Wie-Doet-Het beter te maken?</p>
<p style="margin:0 0 20px;font-size:14px;line-height:1.6;color:#475569;">Laat het ons weten! Antwoord gewoon op deze e-mail met je suggestie \u2014 we lezen elk bericht.</p>
<p style="margin:0 0 4px;font-size:14px;line-height:1.6;color:#1e293b;font-weight:600;">Geen e-mails meer van ons?</p>
<p style="margin:0;font-size:14px;line-height:1.6;color:#475569;">Antwoord op deze e-mail met het woord &quot;afmelden&quot; (of mail naar ${link2}). Wij zetten je dan uit onze mailinglijst \u2014 ${OPT_OUT_PROCESSING_TEXT}. Meer hoef je niet te doen.</p>
</div>`;
}
function wrapEmailHtml(bodyHtml, { replyToEmail = process.env.SES_REPLY_TO_EMAIL } = {}) {
  if (!replyToEmail) throw new Error("SES_REPLY_TO_EMAIL env var is not set");
  return `<!DOCTYPE html><html lang="nl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f4f7fb;font-family:'Segoe UI',Arial,Helvetica,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f7fb;padding:32px 16px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;padding:40px;max-width:600px;">
<tr><td>
<div style="margin-bottom:28px;padding-bottom:20px;border-bottom:1px solid #e2e8f0;">
<span style="font-size:20px;font-weight:700;color:#2080b8;letter-spacing:-0.5px;">wieDoetHet</span>
</div>
<div style="font-size:15px;line-height:1.7;color:#1e293b;">${bodyHtml}</div>
${footerHtml(replyToEmail)}
<div style="margin-top:24px;padding-top:16px;border-top:1px solid #e2e8f0;">
<p style="margin:0;font-size:13px;color:#64748b;">Dit bericht is verstuurd via <a href="https://wiedoethet.nl" style="color:#2080b8;text-decoration:none;">wiedoethet.nl</a></p>
</div>
</td></tr>
</table>
</td></tr>
</table>
</body></html>`;
}

// shared/lifecycle-templates.js
var USER_VARIABLES = ["firstName", "appUrl", "createGroupUrl"];
var GROUP_VARIABLES = [...USER_VARIABLES, "groupName", "groupUrl"];
var link = (label, url) => `<p><a href="${url}"><strong>${label} \u2192</strong></a></p>`;
var LIFECYCLE_TEMPLATES = [
  {
    id: "welcome",
    scope: "user",
    tier: "timely",
    maxAgeHours: 96,
    maxPerUser: 1,
    gapExemptAfter: [],
    variables: USER_VARIABLES,
    defaultSubject: "Welkom bij Wie-Doet-Het, {{firstName}}!",
    defaultBodyHtml: [
      "<p>Hoi {{firstName}},</p>",
      "<p>Je hebt een account aangemaakt bij Wie-Doet-Het, de gratis app om taken te verdelen binnen een groep. Zonder eindeloos appen: jij maakt een lijst, iedereen kiest zelf wat hij of zij doet.</p>",
      "<p>Zo begin je:</p>",
      "<ol><li><p>Maak een groep aan (een etentje, verjaardag, klusdag\u2026)</p></li><li><p>Zet de taken erin</p></li><li><p>Deel de link via WhatsApp \u2014 deelnemers hebben geen account nodig</p></li></ol>",
      link("Maak je eerste groep", "{{createGroupUrl}}")
    ].join("")
  },
  {
    id: "no_group",
    scope: "user",
    tier: "normal",
    maxAgeHours: 168,
    maxPerUser: 1,
    gapExemptAfter: ["welcome"],
    variables: USER_VARIABLES,
    defaultSubject: "Zullen we samen je eerste groep maken?",
    defaultBodyHtml: [
      "<p>Hoi {{firstName}},</p>",
      "<p>je hebt een account bij Wie-Doet-Het, de gratis app om taken te verdelen binnen een groep, maar je hebt nog geen groep gemaakt. Dat kost twee minuten: geef je groep een naam, voeg een paar taken toe en deel de link. Begin gerust klein, je kunt altijd taken toevoegen.</p>",
      link("Start een groep", "{{createGroupUrl}}")
    ].join("")
  },
  {
    id: "no_tasks",
    scope: "group",
    tier: "timely",
    maxAgeHours: 96,
    maxPerUser: 1,
    gapExemptAfter: [],
    variables: GROUP_VARIABLES,
    defaultSubject: "Bijna klaar: voeg taken toe aan {{groupName}}",
    defaultBodyHtml: [
      "<p>Hoi {{firstName}},</p>",
      '<p>je hebt in Wie-Doet-Het, de gratis app om taken te verdelen binnen een groep, de groep "{{groupName}}" aangemaakt \u2014 top! Alleen staan er nog geen taken in, dus er valt nog niets te kiezen. Voeg een paar taken toe (bijv. "Drinken meenemen", "Taart bakken"), dan kun je de link delen.</p>',
      link("Taken toevoegen", "{{groupUrl}}")
    ].join("")
  },
  {
    id: "no_claims",
    scope: "group",
    tier: "normal",
    maxAgeHours: 168,
    maxPerUser: 1,
    gapExemptAfter: [],
    variables: GROUP_VARIABLES,
    defaultSubject: "Nog niemand heeft een taak gekozen in {{groupName}}",
    defaultBodyHtml: [
      "<p>Hoi {{firstName}},</p>",
      '<p>in Wie-Doet-Het, de gratis app om taken te verdelen binnen een groep, staan de taken voor "{{groupName}}" klaar, maar niemand heeft er nog een gekozen. Heb je de link al gedeeld? Een korte herinnering in de groepsapp helpt vaak \u2014 mensen vergeten het snel weer. Tip: houd taken klein en concreet, dan is kiezen makkelijker.</p>',
      link("Naar je groep", "{{groupUrl}}")
    ].join("")
  },
  {
    id: "day_after_event",
    scope: "group",
    tier: "timely",
    maxAgeHours: 96,
    maxPerUser: null,
    gapExemptAfter: [],
    variables: GROUP_VARIABLES,
    defaultSubject: "Hoe was {{groupName}}?",
    defaultBodyHtml: [
      "<p>Hoi {{firstName}},</p>",
      '<p>je hebt "{{groupName}}" georganiseerd met Wie-Doet-Het, de gratis app om taken te verdelen binnen een groep. De datum is inmiddels geweest \u2014 hopelijk was het gezellig! Volgende keer weer iets te organiseren? Je maakt zo een nieuwe groep, en je deelnemers hebben de taken weer snel op een rij.</p>',
      link("Nieuwe groep maken", "{{createGroupUrl}}")
    ].join("")
  },
  {
    id: "dormant_30",
    scope: "user",
    tier: "normal",
    maxAgeHours: null,
    maxPerUser: 1,
    gapExemptAfter: [],
    variables: USER_VARIABLES,
    defaultSubject: "We missen je bij Wie-Doet-Het",
    defaultBodyHtml: [
      "<p>Hoi {{firstName}},</p>",
      "<p>je hebt een account bij Wie-Doet-Het, de gratis app om taken te verdelen binnen een groep. Het is een tijdje geleden dat we je zagen. Staat er weer iets op de planning waarbij iedereen moet meehelpen? Je groepen en taken staan nog gewoon voor je klaar.</p>",
      link("Naar Wie-Doet-Het", "{{appUrl}}")
    ].join("")
  },
  {
    id: "dormant_60",
    scope: "user",
    tier: "normal",
    maxAgeHours: null,
    maxPerUser: 1,
    gapExemptAfter: [],
    variables: USER_VARIABLES,
    defaultSubject: "Nog iets te regelen, {{firstName}}?",
    defaultBodyHtml: [
      "<p>Hoi {{firstName}},</p>",
      "<p>dit is voorlopig het laatste bericht van Wie-Doet-Het, de gratis app om taken te verdelen binnen een groep waar je een account hebt: we willen je inbox niet vullen. Mocht je ooit weer een groep willen organiseren, dan staat Wie-Doet-Het voor je klaar. En vertel ons vooral gerust wat we anders of beter zouden kunnen doen \u2014 je reactie is welkom.</p>",
      link("Naar Wie-Doet-Het", "{{appUrl}}")
    ].join("")
  }
];
var TEMPLATE_IDS = LIFECYCLE_TEMPLATES.map((t) => t.id);
var BY_ID = new Map(LIFECYCLE_TEMPLATES.map((t) => [t.id, t]));
function getTemplate(id) {
  return BY_ID.get(id);
}
function mergeTemplateConfig(definition, config) {
  const subjectOverride = config?.subject ?? null;
  const bodyOverride = config?.bodyHtml ?? null;
  return {
    ...definition,
    enabled: config?.enabled === true,
    enabledAt: config?.enabledAt ?? null,
    subject: subjectOverride ?? definition.defaultSubject,
    bodyHtml: bodyOverride ?? definition.defaultBodyHtml,
    isCustomised: subjectOverride !== null || bodyOverride !== null,
    updatedAt: config?.updatedAt ?? null,
    updatedBy: config?.updatedBy ?? null
  };
}

// shared/mail-render.js
var TOKEN_RE = /\{\{\s*([A-Za-z][A-Za-z0-9]*)\s*\}\}/g;
var FALLBACK_FIRST_NAME = "daar";
var DEFAULT_APP_URL = "https://wiedoethet.nl";
var MAX_SUBJECT_LENGTH = 150;
var MAX_BODY_LENGTH = 5e4;
function escapeHtml2(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function findUnknownTokens(text, allowed) {
  const unknown = [];
  for (const match of String(text ?? "").matchAll(TOKEN_RE)) {
    if (!allowed.includes(match[1]) && !unknown.includes(match[1])) unknown.push(match[1]);
  }
  return unknown;
}
function isEmptyHtml(html) {
  const text = String(html ?? "").replace(/<[^>]*>/g, "").replace(/&nbsp;/gi, " ").trim();
  return text.length === 0;
}
function validateTemplateText({ subject, bodyHtml }, allowedVariables) {
  if (typeof subject === "string") {
    const trimmed = subject.trim();
    if (!trimmed) return "Onderwerp is verplicht";
    if (trimmed.length > MAX_SUBJECT_LENGTH) return `Onderwerp mag maximaal ${MAX_SUBJECT_LENGTH} tekens bevatten`;
  } else if (subject !== void 0 && subject !== null) {
    return "Onderwerp moet tekst zijn";
  }
  if (typeof bodyHtml === "string") {
    if (isEmptyHtml(bodyHtml)) return "Berichttekst is verplicht";
    if (bodyHtml.length > MAX_BODY_LENGTH) return `Berichttekst mag maximaal ${MAX_BODY_LENGTH} tekens bevatten`;
  } else if (bodyHtml !== void 0 && bodyHtml !== null) {
    return "Berichttekst moet tekst zijn";
  }
  const unknown = [
    ...findUnknownTokens(typeof subject === "string" ? subject : "", allowedVariables),
    ...findUnknownTokens(typeof bodyHtml === "string" ? bodyHtml : "", allowedVariables)
  ].filter((token, index, all) => all.indexOf(token) === index);
  if (unknown.length > 0) {
    return `Onbekend of niet toegestaan veld: ${unknown.map((token) => `{{${token}}}`).join(", ")}`;
  }
  return null;
}
function getAppUrl() {
  return (process.env.APP_URL || DEFAULT_APP_URL).replace(/\/+$/, "");
}
function firstNameOf(name) {
  const first = String(name ?? "").trim().split(/\s+/)[0];
  return first || FALLBACK_FIRST_NAME;
}
function buildVariables({ user, group }) {
  const appUrl = getAppUrl();
  const values = {
    firstName: firstNameOf(user?.name),
    appUrl,
    createGroupUrl: `${appUrl}/groups/new`
  };
  if (group) {
    values.groupName = group.name ?? "";
    values.groupUrl = `${appUrl}/groups/${group.id}`;
  }
  return values;
}
function substitute(text, values, transform) {
  return String(text ?? "").replace(TOKEN_RE, (_match, token) => transform(values[token] ?? ""));
}
function renderTemplate({ subject, bodyHtml }, values) {
  return {
    subject: substitute(subject, values, (v) => String(v).replace(/[\r\n]+/g, " ")).trim(),
    bodyHtml: substitute(bodyHtml, values, escapeHtml2)
  };
}

// wiedoethet-admin/index.js
var MAX_INTERNAL_QUERIES = 5;
var MAX_MAIL_RESOLVE_QUERIES = 200;
var MAX_MAIL_RECIPIENTS = 500;
var MAIL_SEND_CONCURRENCY = 5;
async function getStats(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const sevenDaysAgoIso = new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3).toISOString();
  const [totalUsers, totalGroups, newUsers, newGroups, recentUsersRaw, recentGroupsRaw] = await Promise.all([
    queryGsi3("USER", { select: "COUNT" }),
    queryGsi3("GROUP", { select: "COUNT" }),
    queryGsi3("USER", { skGte: sevenDaysAgoIso, select: "COUNT" }),
    queryGsi3("GROUP", { skGte: sevenDaysAgoIso, select: "COUNT" }),
    queryGsi3("USER", { scanIndexForward: false, limit: 5 }),
    queryGsi3("GROUP", { scanIndexForward: false, limit: 5 })
  ]);
  const [recentUsers, recentGroups] = await Promise.all([
    Promise.all(recentUsersRaw.items.map((u) => enrichUserSummary(u))),
    Promise.all(recentGroupsRaw.items.map(async (g) => {
      const initiator = await getItem(`USER#${g.initiatorId}`, "PROFILE");
      return enrichGroupSummary(g, initiator);
    }))
  ]);
  const stats = {
    totalUsers: totalUsers.count,
    totalGroups: totalGroups.count,
    newUsersLast7d: newUsers.count,
    newGroupsLast7d: newGroups.count,
    recentUsers,
    recentGroups,
    generatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  logSuccess({ route: "GET /admin/stats", adminUserId: admin.id, start, resultCount: recentUsers.length + recentGroups.length });
  return ok(stats);
}
async function listUsers(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const params = parseListParams(event);
  if (params.error) return params.error;
  const { limit, exclusiveStartKey, q } = params;
  const filterExpression = q ? "contains(email, :q) OR contains(#name, :q)" : void 0;
  const expressionAttributeNames = q ? { "#name": "name" } : void 0;
  const expressionAttributeValues = q ? { ":q": q } : void 0;
  const [{ items: rawUsers, nextCursor }, totalCount] = await Promise.all([
    queryGsi3Paginated("USER", { limit, exclusiveStartKey, filterExpression, expressionAttributeNames, expressionAttributeValues }),
    countAllMatchingUsers(q)
  ]);
  const items = await Promise.all(rawUsers.map((u) => enrichUserSummary(u)));
  logSuccess({ route: "GET /admin/users", adminUserId: admin.id, start, resultCount: items.length });
  return ok({ items, nextCursor, totalCount });
}
async function countAllMatchingUsers(q) {
  if (!q) {
    const result = await queryGsi3("USER", { select: "COUNT" });
    return result.count;
  }
  let total = 0;
  let exclusiveStartKey;
  for (let loop = 0; loop < MAX_MAIL_RESOLVE_QUERIES; loop++) {
    const result = await queryGsi3("USER", {
      limit: 50,
      exclusiveStartKey,
      filterExpression: "contains(email, :q) OR contains(#name, :q)",
      expressionAttributeNames: { "#name": "name" },
      expressionAttributeValues: { ":q": q }
    });
    total += result.items.length;
    if (!result.lastEvaluatedKey) break;
    exclusiveStartKey = result.lastEvaluatedKey;
  }
  return total;
}
async function mailUsers(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const body = parseBody(event);
  const subject = body.subject?.trim();
  const html = body.html?.trim();
  if (!subject) return badRequest("Onderwerp is verplicht");
  if (!html) return badRequest("Berichttekst is verplicht");
  if (!process.env.SES_REPLY_TO_EMAIL) return serverError(new Error("SES_REPLY_TO_EMAIL env var is not set"));
  let recipients;
  if (body.selectAll === true) {
    const q = typeof body.q === "string" ? body.q.trim() || void 0 : void 0;
    recipients = await resolveAllMatchingUsers(q);
  } else {
    if (!Array.isArray(body.userIds) || body.userIds.length === 0) {
      return badRequest("userIds is verplicht (of selectAll: true)");
    }
    const uniqueIds = [...new Set(body.userIds)];
    const found = await Promise.all(uniqueIds.map((id) => getItem(`USER#${id}`, "PROFILE")));
    recipients = found.filter(Boolean);
  }
  if (recipients.length === 0) return badRequest("Geen ontvangers gevonden");
  const sendable = recipients.filter((user) => user.mailOptOut !== true);
  const skippedOptOut = recipients.length - sendable.length;
  if (sendable.length === 0) {
    logSuccess({ route: "POST /admin/mail", adminUserId: admin.id, start, resultCount: 0 });
    return ok({ sent: 0, failed: 0, failures: [], skippedOptOut });
  }
  if (sendable.length > MAX_MAIL_RECIPIENTS) {
    return badRequest(`Te veel ontvangers (${sendable.length}). Maximum is ${MAX_MAIL_RECIPIENTS} per verzending.`);
  }
  const { sent, failed, failures } = await sendToRecipients(sendable, subject, wrapEmailHtml(html));
  logSuccess({ route: "POST /admin/mail", adminUserId: admin.id, start, resultCount: sent });
  return ok({ sent, failed, failures, skippedOptOut });
}
async function resolveAllMatchingUsers(q) {
  const users = [];
  let exclusiveStartKey;
  for (let loop = 0; loop < MAX_MAIL_RESOLVE_QUERIES; loop++) {
    const result = await queryGsi3("USER", {
      limit: 50,
      exclusiveStartKey,
      filterExpression: q ? "contains(email, :q) OR contains(#name, :q)" : void 0,
      expressionAttributeNames: q ? { "#name": "name" } : void 0,
      expressionAttributeValues: q ? { ":q": q } : void 0
    });
    users.push(...result.items);
    if (!result.lastEvaluatedKey) break;
    exclusiveStartKey = result.lastEvaluatedKey;
  }
  return users;
}
async function sendToRecipients(recipients, subject, html) {
  let sent = 0;
  const failures = [];
  for (let i = 0; i < recipients.length; i += MAIL_SEND_CONCURRENCY) {
    const chunk = recipients.slice(i, i + MAIL_SEND_CONCURRENCY);
    const results = await Promise.all(chunk.map(async (user) => {
      try {
        await sendMail({ to: user.email, subject, html });
        return { ok: true };
      } catch (err) {
        return { ok: false, userId: user.id, email: user.email, message: err.message };
      }
    }));
    for (const result of results) {
      if (result.ok) sent++;
      else failures.push({ userId: result.userId, email: result.email, message: result.message });
    }
  }
  return { sent, failed: failures.length, failures };
}
async function getUserDetail(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const { userId } = event.pathParameters ?? {};
  const user = await getItem(`USER#${userId}`, "PROFILE");
  if (!user) return notFound("Gebruiker niet gevonden");
  const groupItems = (await queryGsi2(`INITIATOR#${userId}`, "GROUP#")).filter((g) => g.SK === "METADATA");
  const groupCount = groupItems.length;
  const mostRecentGroupCreatedAt = groupItems.reduce((max, g) => g.createdAt > max ? g.createdAt : max, "");
  const lastActivityAt = mostRecentGroupCreatedAt > user.createdAt ? mostRecentGroupCreatedAt : user.createdAt;
  const groups = groupItems.map((g) => ({ id: g.id, name: g.name, shareToken: g.shareToken, createdAt: g.createdAt })).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const detail = {
    ...toUserSummaryBase(user),
    mailOptOutAt: user.mailOptOutAt ?? null,
    lastSeenAt: user.lastSeenAt ?? null,
    groupCount,
    lastActivityAt,
    groups
  };
  logSuccess({ route: "GET /admin/users/{userId}", adminUserId: admin.id, start, resultCount: 1 });
  return ok(detail);
}
async function listGroups(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const params = parseListParams(event);
  if (params.error) return params.error;
  const { limit, exclusiveStartKey, q } = params;
  const { items: rawGroups, nextCursor } = await queryGsi3Paginated("GROUP", {
    limit,
    exclusiveStartKey,
    filterExpression: q ? "contains(#name, :q)" : void 0,
    expressionAttributeNames: q ? { "#name": "name" } : void 0,
    expressionAttributeValues: q ? { ":q": q } : void 0
  });
  const uniqueInitiatorIds = [...new Set(rawGroups.map((g) => g.initiatorId))];
  const initiatorRecords = await Promise.all(uniqueInitiatorIds.map((id) => getItem(`USER#${id}`, "PROFILE")));
  const initiatorMap = new Map(initiatorRecords.filter(Boolean).map((u) => [u.id, u]));
  const items = await Promise.all(rawGroups.map((g) => enrichGroupSummary(g, initiatorMap.get(g.initiatorId))));
  logSuccess({ route: "GET /admin/groups", adminUserId: admin.id, start, resultCount: items.length });
  return ok({ items, nextCursor });
}
async function getGroupDetail(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const { groupId } = event.pathParameters ?? {};
  const group = await getItem(`GROUP#${groupId}`, "METADATA");
  if (!group) return notFound("Groep niet gevonden");
  const [initiator, tasks, claims] = await Promise.all([
    getItem(`USER#${group.initiatorId}`, "PROFILE"),
    queryByPk(`GROUP#${groupId}`, "TASK#"),
    queryGsi1(`GCLAIM#${groupId}`)
  ]);
  const claimsByTask = /* @__PURE__ */ new Map();
  for (const c of claims) {
    if (!claimsByTask.has(c.taskId)) claimsByTask.set(c.taskId, []);
    claimsByTask.get(c.taskId).push(c);
  }
  const uniqueClaimers = new Set(claims.map((c) => c.userId ?? c.sessionId));
  const userIds = [...new Set(claims.map((c) => c.userId).filter(Boolean))];
  const userRecords = await Promise.all(userIds.map((uid) => getItem(`USER#${uid}`, "PROFILE")));
  const userMap = Object.fromEntries(userRecords.filter(Boolean).map((u) => [u.id, u.name]));
  const claimerName = (c) => c.userId ? userMap[c.userId] ?? "Onbekend" : c.anonymousName ?? "Anoniem";
  const taskList = tasks.map((t) => {
    const taskClaims = claimsByTask.get(t.id) ?? [];
    return {
      id: t.id,
      title: t.title,
      order: t.order,
      claimCount: taskClaims.length,
      claimedBy: taskClaims.length ? taskClaims.map(claimerName).join(", ") : null
    };
  }).sort((a, b) => a.order - b.order);
  const detail = {
    ...toGroupSummaryBase(group, initiator),
    taskCount: tasks.length,
    memberCount: uniqueClaimers.size,
    tasks: taskList
  };
  logSuccess({ route: "GET /admin/groups/{groupId}", adminUserId: admin.id, start, resultCount: 1 });
  return ok(detail);
}
var MAIL_LOG_STATUSES = ["sent", "failed", "sending"];
var MAIL_LOG_PAGE_SIZE = 100;
var MAIL_LOG_MAX_QUERIES = 20;
function toTemplateItem(definition, config) {
  const merged = mergeTemplateConfig(definition, config);
  return {
    id: merged.id,
    scope: merged.scope,
    tier: merged.tier,
    enabled: merged.enabled,
    subject: merged.subject,
    bodyHtml: merged.bodyHtml,
    defaultSubject: merged.defaultSubject,
    defaultBodyHtml: merged.defaultBodyHtml,
    isCustomised: merged.isCustomised,
    variables: merged.variables,
    updatedAt: merged.updatedAt,
    updatedBy: merged.updatedBy
  };
}
async function getTemplateConfig(templateId) {
  const { PK, SK } = keys.mailTemplate(templateId);
  return getItem(PK, SK);
}
async function listMailTemplates(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const state = keys.mailState();
  const [configs, lastRunItem, masterItem] = await Promise.all([
    Promise.all(LIFECYCLE_TEMPLATES.map((t) => getTemplateConfig(t.id))),
    getItem(state.PK, state.SK),
    getMailMasterItem()
  ]);
  const items = LIFECYCLE_TEMPLATES.map((definition, i) => toTemplateItem(definition, configs[i]));
  const lastRun = lastRunItem ? {
    at: lastRunItem.at,
    masterEnabled: lastRunItem.masterEnabled === true,
    killSwitch: lastRunItem.killSwitch === true,
    dryRun: lastRunItem.dryRun === true,
    evaluated: lastRunItem.evaluated ?? 0,
    sent: lastRunItem.sent ?? 0,
    failed: lastRunItem.failed ?? 0,
    skippedByCap: lastRunItem.skippedByCap ?? 0
  } : null;
  logSuccess({ route: "GET /admin/mail-templates", adminUserId: admin.id, start, resultCount: items.length });
  return ok({ items, lastRun, master: toMasterItem(masterItem) });
}
async function getMailMasterItem() {
  const { PK, SK } = keys.mailMaster();
  return getItem(PK, SK);
}
function toMasterItem(item) {
  return {
    enabled: item?.enabled === true,
    updatedAt: item?.updatedAt ?? null,
    updatedBy: item?.updatedBy ?? null
  };
}
async function setMailMaster(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const body = parseBody(event);
  if (typeof body.enabled !== "boolean") return badRequest("enabled moet true of false zijn");
  const { PK, SK } = keys.mailMaster();
  const next = { enabled: body.enabled, updatedAt: (/* @__PURE__ */ new Date()).toISOString(), updatedBy: admin.id };
  await updateItem(PK, SK, next);
  logSuccess({ route: "PATCH /admin/mail-master", adminUserId: admin.id, start, resultCount: 1 });
  return ok(toMasterItem(next));
}
async function updateMailTemplate(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const { templateId } = event.pathParameters ?? {};
  const definition = getTemplate(templateId);
  if (!definition) return notFound("Sjabloon niet gevonden");
  const body = parseBody(event);
  const has = (field) => Object.prototype.hasOwnProperty.call(body, field);
  if (!has("enabled") && !has("subject") && !has("bodyHtml")) return badRequest("Geen wijzigingen opgegeven");
  if (has("enabled") && typeof body.enabled !== "boolean") return badRequest("enabled moet true of false zijn");
  const validationError = validateTemplateText({ subject: body.subject, bodyHtml: body.bodyHtml }, definition.variables);
  if (validationError) return badRequest(validationError);
  const { PK, SK } = keys.mailTemplate(templateId);
  const existing = await getItem(PK, SK);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const enabled = has("enabled") ? body.enabled : existing?.enabled === true;
  const next = {
    enabled,
    // null clears the override (back to the default text); admin HTML is stored as-is
    subject: has("subject") ? typeof body.subject === "string" ? body.subject.trim() : null : existing?.subject ?? null,
    bodyHtml: has("bodyHtml") ? typeof body.bodyHtml === "string" ? body.bodyHtml : null : existing?.bodyHtml ?? null,
    // false -> true restarts the clock the dormant_* templates measure from; true -> false leaves it
    enabledAt: enabled && existing?.enabled !== true ? now : existing?.enabledAt ?? null,
    updatedAt: now,
    updatedBy: admin.id
  };
  await updateItem(PK, SK, next);
  logSuccess({ route: "PATCH /admin/mail-templates/{templateId}", adminUserId: admin.id, start, resultCount: 1 });
  return ok(toTemplateItem(definition, next));
}
async function sendTemplateTest(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const { templateId } = event.pathParameters ?? {};
  const definition = getTemplate(templateId);
  if (!definition) return notFound("Sjabloon niet gevonden");
  const merged = mergeTemplateConfig(definition, await getTemplateConfig(templateId));
  const values = buildVariables({
    user: admin,
    group: definition.scope === "group" ? { id: "voorbeeld", name: "Voorbeeldgroep" } : void 0
  });
  if (definition.scope === "group") values.groupUrl = `${getAppUrl()}/dashboard`;
  const rendered = renderTemplate({ subject: merged.subject, bodyHtml: merged.bodyHtml }, values);
  try {
    await sendMail({ to: admin.email, subject: `[TEST] ${rendered.subject}`, html: wrapEmailHtml(rendered.bodyHtml) });
  } catch (err) {
    console.error(JSON.stringify({ level: "error", route: "POST /admin/mail-templates/{templateId}/test", message: err.message }));
    return badGateway(`Testmail versturen mislukt: ${err.message}`);
  }
  logSuccess({ route: "POST /admin/mail-templates/{templateId}/test", adminUserId: admin.id, start, resultCount: 1 });
  return ok({ sent: true, to: admin.email });
}
async function listMailLog(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const params = parseListParams(event);
  if (params.error) return params.error;
  const { limit, exclusiveStartKey, q } = params;
  const qs = event.queryStringParameters ?? {};
  const templateId = qs.templateId || void 0;
  const status = qs.status || void 0;
  if (templateId && !getTemplate(templateId)) return badRequest("Onbekend sjabloon");
  if (status && !MAIL_LOG_STATUSES.includes(status)) return badRequest("Ongeldige status");
  const conditions = [];
  const expressionAttributeNames = {};
  const expressionAttributeValues = {};
  if (templateId) {
    conditions.push("templateId = :templateId");
    expressionAttributeValues[":templateId"] = templateId;
  }
  if (status) {
    conditions.push("#status = :status");
    expressionAttributeNames["#status"] = "status";
    expressionAttributeValues[":status"] = status;
  }
  if (q) {
    conditions.push("contains(email, :q)");
    expressionAttributeValues[":q"] = q.toLowerCase();
  }
  const filtered = conditions.length > 0;
  const { items: rows, nextCursor } = await queryGsi3Paginated("MAILLOG", {
    limit,
    exclusiveStartKey,
    pageSize: filtered ? MAIL_LOG_PAGE_SIZE : limit,
    maxQueries: filtered ? MAIL_LOG_MAX_QUERIES : MAX_INTERNAL_QUERIES,
    filterExpression: filtered ? conditions.join(" AND ") : void 0,
    expressionAttributeNames: Object.keys(expressionAttributeNames).length ? expressionAttributeNames : void 0,
    expressionAttributeValues: filtered ? expressionAttributeValues : void 0
  });
  const items = rows.map((row) => {
    const { PK, SK, GSI3PK, GSI3SK, type, ...entry } = row;
    return entry;
  });
  logSuccess({ route: "GET /admin/mail-log", adminUserId: admin.id, start, resultCount: items.length });
  return ok({ items, nextCursor });
}
async function setUserMailOptOut(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const { userId } = event.pathParameters ?? {};
  const { optOut } = parseBody(event);
  if (typeof optOut !== "boolean") return badRequest("optOut moet true of false zijn");
  const user = await getItem(`USER#${userId}`, "PROFILE");
  if (!user) return notFound("Gebruiker niet gevonden");
  const current = user.mailOptOut === true;
  if (optOut === current) {
    logSuccess({ route: "PATCH /admin/users/{userId}/mail-opt-out", adminUserId: admin.id, start, resultCount: 1 });
    return ok({ id: user.id, mailOptOut: current, mailOptOutAt: current ? user.mailOptOutAt ?? null : null });
  }
  const mailOptOutAt = optOut ? (/* @__PURE__ */ new Date()).toISOString() : null;
  await updateItem(`USER#${userId}`, "PROFILE", { mailOptOut: optOut, mailOptOutAt, mailOptOutBy: admin.id });
  logSuccess({ route: "PATCH /admin/users/{userId}/mail-opt-out", adminUserId: admin.id, start, resultCount: 1 });
  return ok({ id: user.id, mailOptOut: optOut, mailOptOutAt });
}
function toUserSummaryBase(user) {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role ?? "user",
    mailOptOut: user.mailOptOut === true,
    createdAt: user.createdAt
  };
}
async function enrichUserSummary(user) {
  const groups = (await queryGsi2(`INITIATOR#${user.id}`, "GROUP#")).filter((g) => g.SK === "METADATA");
  const mostRecentGroupCreatedAt = groups.reduce((max, g) => g.createdAt > max ? g.createdAt : max, "");
  const lastActivityAt = mostRecentGroupCreatedAt > user.createdAt ? mostRecentGroupCreatedAt : user.createdAt;
  return { ...toUserSummaryBase(user), groupCount: groups.length, lastActivityAt };
}
function toGroupSummaryBase(group, initiator) {
  return {
    id: group.id,
    name: group.name,
    pictureUrl: group.pictureUrl ?? null,
    shareToken: group.shareToken,
    scorecardVisibility: group.scorecardVisibility,
    initiatorId: group.initiatorId,
    initiatorName: initiator?.name ?? "Onbekend",
    initiatorEmail: initiator?.email ?? "",
    createdAt: group.createdAt
  };
}
async function enrichGroupSummary(group, initiator) {
  const [tasks, claims] = await Promise.all([
    queryByPk(`GROUP#${group.id}`, "TASK#"),
    queryGsi1(`GCLAIM#${group.id}`)
  ]);
  const uniqueClaimers = new Set(claims.map((c) => c.userId ?? c.sessionId));
  return { ...toGroupSummaryBase(group, initiator), taskCount: tasks.length, memberCount: uniqueClaimers.size };
}
async function queryGsi3Paginated(gsi3pk, {
  limit,
  exclusiveStartKey,
  filterExpression,
  expressionAttributeNames,
  expressionAttributeValues,
  pageSize = limit,
  // DynamoDB read size per internal query; raise it for sparse filters
  maxQueries = MAX_INTERNAL_QUERIES
}) {
  const items = [];
  let cursor = exclusiveStartKey;
  let lastEvaluatedKey = null;
  for (let loop = 0; loop < maxQueries && items.length < limit; loop++) {
    const result = await queryGsi3(gsi3pk, {
      scanIndexForward: false,
      limit: pageSize,
      exclusiveStartKey: cursor,
      filterExpression,
      expressionAttributeNames,
      expressionAttributeValues
    });
    items.push(...result.items);
    lastEvaluatedKey = result.lastEvaluatedKey;
    cursor = result.lastEvaluatedKey ?? void 0;
    if (!result.lastEvaluatedKey) break;
  }
  if (items.length > limit) {
    const trimmed = items.slice(0, limit);
    const lastReturned = trimmed[trimmed.length - 1];
    return { items: trimmed, nextCursor: encodeCursor(exclusiveStartKeyFromItem(lastReturned)) };
  }
  return { items, nextCursor: lastEvaluatedKey ? encodeCursor(lastEvaluatedKey) : null };
}
function exclusiveStartKeyFromItem(item) {
  return { PK: item.PK, SK: item.SK, GSI3PK: item.GSI3PK, GSI3SK: item.GSI3SK };
}
function encodeCursor(lastEvaluatedKey) {
  return lastEvaluatedKey ? Buffer.from(JSON.stringify(lastEvaluatedKey)).toString("base64url") : null;
}
function decodeCursor(cursor) {
  try {
    return JSON.parse(Buffer.from(cursor, "base64url").toString("utf8"));
  } catch {
    return void 0;
  }
}
function parseListParams(event) {
  const qs = event.queryStringParameters ?? {};
  let limit = 20;
  if (qs.limit !== void 0 && qs.limit !== "") {
    const n = Number(qs.limit);
    if (!Number.isInteger(n) || n < 1 || n > 50) {
      return { error: badRequest("limit moet een geheel getal tussen 1 en 50 zijn") };
    }
    limit = n;
  }
  let exclusiveStartKey;
  if (qs.cursor) {
    exclusiveStartKey = decodeCursor(qs.cursor);
    if (exclusiveStartKey === void 0) return { error: badRequest("Ongeldige cursor") };
  }
  const q = qs.q?.trim() || void 0;
  return { limit, exclusiveStartKey, q };
}
async function requireAdmin(event) {
  const token = extractBearer(event);
  if (!token) return { error: unauthorized() };
  let payload;
  try {
    payload = verifyJwt(token);
  } catch {
    return { error: unauthorized() };
  }
  const user = await getItem(`USER#${payload.sub}`, "PROFILE");
  if (!user) return { error: unauthorized() };
  if (user.role !== "admin") return { error: forbidden() };
  return { user };
}
function logSuccess({ route, adminUserId, start, resultCount }) {
  console.log(JSON.stringify({
    level: "info",
    route,
    adminUserId,
    durationMs: Date.now() - start,
    resultCount
  }));
}
var handler = async (event) => {
  process.env.TABLE_NAME = event.stageVariables?.tableName ?? process.env.TABLE_NAME ?? "wdh-main";
  try {
    const method = event.httpMethod;
    const path = event.path?.replace(/\/$/, "");
    if (method === "OPTIONS") return { statusCode: 204, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type,Authorization", "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS" }, body: "" };
    if (method === "GET" && path === "/admin/stats") return await getStats(event);
    if (method === "GET" && path === "/admin/users") return await listUsers(event);
    if (method === "GET" && /^\/admin\/users\/[^/]+$/.test(path)) return await getUserDetail(event);
    if (method === "GET" && path === "/admin/groups") return await listGroups(event);
    if (method === "GET" && /^\/admin\/groups\/[^/]+$/.test(path)) return await getGroupDetail(event);
    if (method === "POST" && path === "/admin/mail") return await mailUsers(event);
    if (method === "GET" && path === "/admin/mail-templates") return await listMailTemplates(event);
    if (method === "PATCH" && path === "/admin/mail-master") return await setMailMaster(event);
    if (method === "PATCH" && /^\/admin\/mail-templates\/[^/]+$/.test(path)) return await updateMailTemplate(event);
    if (method === "POST" && /^\/admin\/mail-templates\/[^/]+\/test$/.test(path)) return await sendTemplateTest(event);
    if (method === "GET" && path === "/admin/mail-log") return await listMailLog(event);
    if (method === "PATCH" && /^\/admin\/users\/[^/]+\/mail-opt-out$/.test(path)) return await setUserMailOptOut(event);
    return { statusCode: 404, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: "Route niet gevonden" }) };
  } catch (err) {
    return serverError(err);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
