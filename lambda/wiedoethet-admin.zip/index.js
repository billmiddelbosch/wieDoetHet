var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// wiedoethet-admin/index.js
var index_exports = {};
__export(index_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(index_exports);

// shared/http.js
var CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS"
};
function ok(data) {
  return { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify(data) };
}
function badRequest(message = "Ongeldig verzoek") {
  return { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function unauthorized(message = "Niet ingelogd") {
  return { statusCode: 401, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function forbidden(message = "Geen toegang") {
  return { statusCode: 403, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function notFound(message = "Niet gevonden") {
  return { statusCode: 404, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function serverError(err) {
  console.error(err);
  return {
    statusCode: 500,
    headers: CORS_HEADERS,
    body: JSON.stringify({ message: "Interne serverfout" })
  };
}
function extractBearer(event) {
  const auth = event.headers?.Authorization ?? event.headers?.authorization ?? "";
  const token = auth.replace(/^Bearer\s+/i, "");
  return token || null;
}

// shared/jwt.js
var import_node_crypto = require("node:crypto");
var SECRET = process.env.JWT_SECRET;
var EXPIRES_SEC = Number(process.env.JWT_EXPIRES_SEC ?? 2592e3);
function b64urlDecode(str) {
  return Buffer.from(str, "base64url").toString("utf8");
}
function sign(header, body) {
  return (0, import_node_crypto.createHmac)("sha256", SECRET).update(`${header}.${body}`).digest("base64url");
}
function verifyJwt(token) {
  if (!SECRET) throw new Error("JWT_SECRET env var is not set");
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Malformed token");
  const [header, body, sig] = parts;
  const expected = sign(header, body);
  if (sig.length !== expected.length) throw new Error("Invalid signature");
  let diff = 0;
  for (let i = 0; i < sig.length; i++) diff |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
  if (diff !== 0) throw new Error("Invalid signature");
  const payload = JSON.parse(b64urlDecode(body));
  if (payload.exp < Math.floor(Date.now() / 1e3)) throw new Error("Token expired");
  return payload;
}

// shared/db.js
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var client = new import_client_dynamodb.DynamoDBClient({});
var ddb = import_lib_dynamodb.DynamoDBDocumentClient.from(client, {
  marshallOptions: { removeUndefinedValues: true }
});
var table = () => process.env.TABLE_NAME ?? "wdh-main";
async function getItem(pk, sk) {
  const { Item } = await ddb.send(new import_lib_dynamodb.GetCommand({ TableName: table(), Key: { PK: pk, SK: sk } }));
  return Item ?? null;
}
async function queryByPk(pk, skPrefix = null, indexName = null) {
  const params = {
    TableName: table(),
    KeyConditionExpression: skPrefix ? "PK = :pk AND begins_with(SK, :prefix)" : "PK = :pk",
    ExpressionAttributeValues: skPrefix ? { ":pk": pk, ":prefix": skPrefix } : { ":pk": pk }
  };
  if (indexName) {
    params.IndexName = indexName;
    params.KeyConditionExpression = params.KeyConditionExpression.replace(/\bPK\b/g, indexName === "GSI1" ? "GSI1PK" : "GSI2PK").replace(/\bSK\b/g, indexName === "GSI1" ? "GSI1SK" : "GSI2SK");
  }
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}
async function queryGsi1(gsi1pk, gsi1skPrefix = null) {
  const params = {
    TableName: table(),
    IndexName: "GSI1",
    KeyConditionExpression: gsi1skPrefix ? "GSI1PK = :pk AND begins_with(GSI1SK, :prefix)" : "GSI1PK = :pk",
    ExpressionAttributeValues: gsi1skPrefix ? { ":pk": gsi1pk, ":prefix": gsi1skPrefix } : { ":pk": gsi1pk }
  };
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}
async function queryGsi2(gsi2pk, gsi2skPrefix = null) {
  const params = {
    TableName: table(),
    IndexName: "GSI2",
    KeyConditionExpression: gsi2skPrefix ? "GSI2PK = :pk AND begins_with(GSI2SK, :prefix)" : "GSI2PK = :pk",
    ExpressionAttributeValues: gsi2skPrefix ? { ":pk": gsi2pk, ":prefix": gsi2skPrefix } : { ":pk": gsi2pk }
  };
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}
async function queryGsi3(gsi3pk, {
  skGte,
  limit,
  exclusiveStartKey,
  scanIndexForward = true,
  filterExpression,
  expressionAttributeNames,
  expressionAttributeValues,
  select
} = {}) {
  const names = { ...expressionAttributeNames };
  const values = { ":pk": gsi3pk, ...expressionAttributeValues };
  let keyCondition = "GSI3PK = :pk";
  if (skGte !== void 0) {
    keyCondition += " AND GSI3SK >= :skGte";
    values[":skGte"] = skGte;
  }
  const params = {
    TableName: table(),
    IndexName: "GSI3",
    KeyConditionExpression: keyCondition,
    ExpressionAttributeValues: values,
    ScanIndexForward: scanIndexForward
  };
  if (Object.keys(names).length) params.ExpressionAttributeNames = names;
  if (limit !== void 0) params.Limit = limit;
  if (exclusiveStartKey !== void 0) params.ExclusiveStartKey = exclusiveStartKey;
  if (filterExpression) params.FilterExpression = filterExpression;
  if (select) params.Select = select;
  const { Items, LastEvaluatedKey, Count } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return { items: Items ?? [], lastEvaluatedKey: LastEvaluatedKey ?? null, count: Count };
}

// wiedoethet-admin/index.js
var MAX_INTERNAL_QUERIES = 5;
async function getStats(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const sevenDaysAgoIso = new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3).toISOString();
  const [totalUsers, totalGroups, newUsers, newGroups, recentUsersRaw, recentGroupsRaw] = await Promise.all([
    queryGsi3("USER", { select: "COUNT" }),
    queryGsi3("GROUP", { select: "COUNT" }),
    queryGsi3("USER", { skGte: sevenDaysAgoIso, select: "COUNT" }),
    queryGsi3("GROUP", { skGte: sevenDaysAgoIso, select: "COUNT" }),
    queryGsi3("USER", { scanIndexForward: false, limit: 5 }),
    queryGsi3("GROUP", { scanIndexForward: false, limit: 5 })
  ]);
  const [recentUsers, recentGroups] = await Promise.all([
    Promise.all(recentUsersRaw.items.map((u) => enrichUserSummary(u))),
    Promise.all(recentGroupsRaw.items.map(async (g) => {
      const initiator = await getItem(`USER#${g.initiatorId}`, "PROFILE");
      return enrichGroupSummary(g, initiator);
    }))
  ]);
  const stats = {
    totalUsers: totalUsers.count,
    totalGroups: totalGroups.count,
    newUsersLast7d: newUsers.count,
    newGroupsLast7d: newGroups.count,
    recentUsers,
    recentGroups,
    generatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  logSuccess({ route: "GET /admin/stats", adminUserId: admin.id, start, resultCount: recentUsers.length + recentGroups.length });
  return ok(stats);
}
async function listUsers(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const params = parseListParams(event);
  if (params.error) return params.error;
  const { limit, exclusiveStartKey, q } = params;
  const { items: rawUsers, nextCursor } = await queryGsi3Paginated("USER", {
    limit,
    exclusiveStartKey,
    filterExpression: q ? "contains(email, :q) OR contains(#name, :q)" : void 0,
    expressionAttributeNames: q ? { "#name": "name" } : void 0,
    expressionAttributeValues: q ? { ":q": q } : void 0
  });
  const items = await Promise.all(rawUsers.map((u) => enrichUserSummary(u)));
  logSuccess({ route: "GET /admin/users", adminUserId: admin.id, start, resultCount: items.length });
  return ok({ items, nextCursor });
}
async function getUserDetail(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const { userId } = event.pathParameters ?? {};
  const user = await getItem(`USER#${userId}`, "PROFILE");
  if (!user) return notFound("Gebruiker niet gevonden");
  const groupItems = (await queryGsi2(`INITIATOR#${userId}`, "GROUP#")).filter((g) => g.SK === "METADATA");
  const groupCount = groupItems.length;
  const mostRecentGroupCreatedAt = groupItems.reduce((max, g) => g.createdAt > max ? g.createdAt : max, "");
  const lastActivityAt = mostRecentGroupCreatedAt > user.createdAt ? mostRecentGroupCreatedAt : user.createdAt;
  const groups = groupItems.map((g) => ({ id: g.id, name: g.name, shareToken: g.shareToken, createdAt: g.createdAt })).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const detail = { ...toUserSummaryBase(user), groupCount, lastActivityAt, groups };
  logSuccess({ route: "GET /admin/users/{userId}", adminUserId: admin.id, start, resultCount: 1 });
  return ok(detail);
}
async function listGroups(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const params = parseListParams(event);
  if (params.error) return params.error;
  const { limit, exclusiveStartKey, q } = params;
  const { items: rawGroups, nextCursor } = await queryGsi3Paginated("GROUP", {
    limit,
    exclusiveStartKey,
    filterExpression: q ? "contains(#name, :q)" : void 0,
    expressionAttributeNames: q ? { "#name": "name" } : void 0,
    expressionAttributeValues: q ? { ":q": q } : void 0
  });
  const uniqueInitiatorIds = [...new Set(rawGroups.map((g) => g.initiatorId))];
  const initiatorRecords = await Promise.all(uniqueInitiatorIds.map((id) => getItem(`USER#${id}`, "PROFILE")));
  const initiatorMap = new Map(initiatorRecords.filter(Boolean).map((u) => [u.id, u]));
  const items = await Promise.all(rawGroups.map((g) => enrichGroupSummary(g, initiatorMap.get(g.initiatorId))));
  logSuccess({ route: "GET /admin/groups", adminUserId: admin.id, start, resultCount: items.length });
  return ok({ items, nextCursor });
}
async function getGroupDetail(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const { groupId } = event.pathParameters ?? {};
  const group = await getItem(`GROUP#${groupId}`, "METADATA");
  if (!group) return notFound("Groep niet gevonden");
  const [initiator, tasks, claims] = await Promise.all([
    getItem(`USER#${group.initiatorId}`, "PROFILE"),
    queryByPk(`GROUP#${groupId}`, "TASK#"),
    queryGsi1(`GCLAIM#${groupId}`)
  ]);
  const claimCountByTask = /* @__PURE__ */ new Map();
  for (const c of claims) {
    claimCountByTask.set(c.taskId, (claimCountByTask.get(c.taskId) ?? 0) + 1);
  }
  const uniqueClaimers = new Set(claims.map((c) => c.userId ?? c.sessionId));
  const taskList = tasks.map((t) => ({ id: t.id, title: t.title, order: t.order, claimCount: claimCountByTask.get(t.id) ?? 0 })).sort((a, b) => a.order - b.order);
  const detail = {
    ...toGroupSummaryBase(group, initiator),
    taskCount: tasks.length,
    memberCount: uniqueClaimers.size,
    tasks: taskList
  };
  logSuccess({ route: "GET /admin/groups/{groupId}", adminUserId: admin.id, start, resultCount: 1 });
  return ok(detail);
}
function toUserSummaryBase(user) {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role ?? "user",
    createdAt: user.createdAt
  };
}
async function enrichUserSummary(user) {
  const groups = (await queryGsi2(`INITIATOR#${user.id}`, "GROUP#")).filter((g) => g.SK === "METADATA");
  const mostRecentGroupCreatedAt = groups.reduce((max, g) => g.createdAt > max ? g.createdAt : max, "");
  const lastActivityAt = mostRecentGroupCreatedAt > user.createdAt ? mostRecentGroupCreatedAt : user.createdAt;
  return { ...toUserSummaryBase(user), groupCount: groups.length, lastActivityAt };
}
function toGroupSummaryBase(group, initiator) {
  return {
    id: group.id,
    name: group.name,
    pictureUrl: group.pictureUrl ?? null,
    initiatorId: group.initiatorId,
    initiatorName: initiator?.name ?? "Onbekend",
    initiatorEmail: initiator?.email ?? "",
    createdAt: group.createdAt
  };
}
async function enrichGroupSummary(group, initiator) {
  const [tasks, claims] = await Promise.all([
    queryByPk(`GROUP#${group.id}`, "TASK#"),
    queryGsi1(`GCLAIM#${group.id}`)
  ]);
  const uniqueClaimers = new Set(claims.map((c) => c.userId ?? c.sessionId));
  return { ...toGroupSummaryBase(group, initiator), taskCount: tasks.length, memberCount: uniqueClaimers.size };
}
async function queryGsi3Paginated(gsi3pk, { limit, exclusiveStartKey, filterExpression, expressionAttributeNames, expressionAttributeValues }) {
  const items = [];
  let cursor = exclusiveStartKey;
  let lastEvaluatedKey = null;
  for (let loop = 0; loop < MAX_INTERNAL_QUERIES && items.length < limit; loop++) {
    const result = await queryGsi3(gsi3pk, {
      scanIndexForward: false,
      limit,
      exclusiveStartKey: cursor,
      filterExpression,
      expressionAttributeNames,
      expressionAttributeValues
    });
    items.push(...result.items);
    lastEvaluatedKey = result.lastEvaluatedKey;
    cursor = result.lastEvaluatedKey ?? void 0;
    if (!result.lastEvaluatedKey) break;
  }
  if (items.length > limit) {
    const trimmed = items.slice(0, limit);
    const lastReturned = trimmed[trimmed.length - 1];
    return { items: trimmed, nextCursor: encodeCursor(exclusiveStartKeyFromItem(lastReturned)) };
  }
  return { items, nextCursor: lastEvaluatedKey ? encodeCursor(lastEvaluatedKey) : null };
}
function exclusiveStartKeyFromItem(item) {
  return { PK: item.PK, SK: item.SK, GSI3PK: item.GSI3PK, GSI3SK: item.GSI3SK };
}
function encodeCursor(lastEvaluatedKey) {
  return lastEvaluatedKey ? Buffer.from(JSON.stringify(lastEvaluatedKey)).toString("base64url") : null;
}
function decodeCursor(cursor) {
  try {
    return JSON.parse(Buffer.from(cursor, "base64url").toString("utf8"));
  } catch {
    return void 0;
  }
}
function parseListParams(event) {
  const qs = event.queryStringParameters ?? {};
  let limit = 20;
  if (qs.limit !== void 0 && qs.limit !== "") {
    const n = Number(qs.limit);
    if (!Number.isInteger(n) || n < 1 || n > 50) {
      return { error: badRequest("limit moet een geheel getal tussen 1 en 50 zijn") };
    }
    limit = n;
  }
  let exclusiveStartKey;
  if (qs.cursor) {
    exclusiveStartKey = decodeCursor(qs.cursor);
    if (exclusiveStartKey === void 0) return { error: badRequest("Ongeldige cursor") };
  }
  const q = qs.q?.trim() || void 0;
  return { limit, exclusiveStartKey, q };
}
async function requireAdmin(event) {
  const token = extractBearer(event);
  if (!token) return { error: unauthorized() };
  let payload;
  try {
    payload = verifyJwt(token);
  } catch {
    return { error: unauthorized() };
  }
  const user = await getItem(`USER#${payload.sub}`, "PROFILE");
  if (!user) return { error: unauthorized() };
  if (user.role !== "admin") return { error: forbidden() };
  return { user };
}
function logSuccess({ route, adminUserId, start, resultCount }) {
  console.log(JSON.stringify({
    level: "info",
    route,
    adminUserId,
    durationMs: Date.now() - start,
    resultCount
  }));
}
var handler = async (event) => {
  process.env.TABLE_NAME = event.stageVariables?.tableName ?? process.env.TABLE_NAME ?? "wdh-main";
  try {
    const method = event.httpMethod;
    const path = event.path?.replace(/\/$/, "");
    if (method === "OPTIONS") return { statusCode: 204, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type,Authorization", "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS" }, body: "" };
    if (method === "GET" && path === "/admin/stats") return await getStats(event);
    if (method === "GET" && path === "/admin/users") return await listUsers(event);
    if (method === "GET" && /^\/admin\/users\/[^/]+$/.test(path)) return await getUserDetail(event);
    if (method === "GET" && path === "/admin/groups") return await listGroups(event);
    if (method === "GET" && /^\/admin\/groups\/[^/]+$/.test(path)) return await getGroupDetail(event);
    return { statusCode: 404, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: "Route niet gevonden" }) };
  } catch (err) {
    return serverError(err);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
