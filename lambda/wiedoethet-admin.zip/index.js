var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// wiedoethet-admin/index.js
var index_exports = {};
__export(index_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(index_exports);

// shared/http.js
var CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS"
};
function ok(data) {
  return { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify(data) };
}
function badRequest(message = "Ongeldig verzoek") {
  return { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function unauthorized(message = "Niet ingelogd") {
  return { statusCode: 401, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function forbidden(message = "Geen toegang") {
  return { statusCode: 403, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function notFound(message = "Niet gevonden") {
  return { statusCode: 404, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function serverError(err) {
  console.error(err);
  return {
    statusCode: 500,
    headers: CORS_HEADERS,
    body: JSON.stringify({ message: "Interne serverfout" })
  };
}
function parseBody(event) {
  try {
    return event.body ? JSON.parse(event.body) : {};
  } catch {
    return {};
  }
}
function extractBearer(event) {
  const auth = event.headers?.Authorization ?? event.headers?.authorization ?? "";
  const token = auth.replace(/^Bearer\s+/i, "");
  return token || null;
}

// shared/jwt.js
var import_node_crypto = require("node:crypto");
var SECRET = process.env.JWT_SECRET;
var EXPIRES_SEC = Number(process.env.JWT_EXPIRES_SEC ?? 2592e3);
function b64urlDecode(str) {
  return Buffer.from(str, "base64url").toString("utf8");
}
function sign(header, body) {
  return (0, import_node_crypto.createHmac)("sha256", SECRET).update(`${header}.${body}`).digest("base64url");
}
function verifyJwt(token) {
  if (!SECRET) throw new Error("JWT_SECRET env var is not set");
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Malformed token");
  const [header, body, sig] = parts;
  const expected = sign(header, body);
  if (sig.length !== expected.length) throw new Error("Invalid signature");
  let diff = 0;
  for (let i = 0; i < sig.length; i++) diff |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
  if (diff !== 0) throw new Error("Invalid signature");
  const payload = JSON.parse(b64urlDecode(body));
  if (payload.exp < Math.floor(Date.now() / 1e3)) throw new Error("Token expired");
  return payload;
}

// shared/db.js
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var client = new import_client_dynamodb.DynamoDBClient({});
var ddb = import_lib_dynamodb.DynamoDBDocumentClient.from(client, {
  marshallOptions: { removeUndefinedValues: true }
});
var table = () => process.env.TABLE_NAME ?? "wdh-main";
async function getItem(pk, sk) {
  const { Item } = await ddb.send(new import_lib_dynamodb.GetCommand({ TableName: table(), Key: { PK: pk, SK: sk } }));
  return Item ?? null;
}
async function queryByPk(pk, skPrefix = null, indexName = null) {
  const params = {
    TableName: table(),
    KeyConditionExpression: skPrefix ? "PK = :pk AND begins_with(SK, :prefix)" : "PK = :pk",
    ExpressionAttributeValues: skPrefix ? { ":pk": pk, ":prefix": skPrefix } : { ":pk": pk }
  };
  if (indexName) {
    params.IndexName = indexName;
    params.KeyConditionExpression = params.KeyConditionExpression.replace(/\bPK\b/g, indexName === "GSI1" ? "GSI1PK" : "GSI2PK").replace(/\bSK\b/g, indexName === "GSI1" ? "GSI1SK" : "GSI2SK");
  }
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}
async function queryGsi1(gsi1pk, gsi1skPrefix = null) {
  const params = {
    TableName: table(),
    IndexName: "GSI1",
    KeyConditionExpression: gsi1skPrefix ? "GSI1PK = :pk AND begins_with(GSI1SK, :prefix)" : "GSI1PK = :pk",
    ExpressionAttributeValues: gsi1skPrefix ? { ":pk": gsi1pk, ":prefix": gsi1skPrefix } : { ":pk": gsi1pk }
  };
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}
async function queryGsi2(gsi2pk, gsi2skPrefix = null) {
  const params = {
    TableName: table(),
    IndexName: "GSI2",
    KeyConditionExpression: gsi2skPrefix ? "GSI2PK = :pk AND begins_with(GSI2SK, :prefix)" : "GSI2PK = :pk",
    ExpressionAttributeValues: gsi2skPrefix ? { ":pk": gsi2pk, ":prefix": gsi2skPrefix } : { ":pk": gsi2pk }
  };
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}
async function queryGsi3(gsi3pk, {
  skGte,
  limit,
  exclusiveStartKey,
  scanIndexForward = true,
  filterExpression,
  expressionAttributeNames,
  expressionAttributeValues,
  select
} = {}) {
  const names = { ...expressionAttributeNames };
  const values = { ":pk": gsi3pk, ...expressionAttributeValues };
  let keyCondition = "GSI3PK = :pk";
  if (skGte !== void 0) {
    keyCondition += " AND GSI3SK >= :skGte";
    values[":skGte"] = skGte;
  }
  const params = {
    TableName: table(),
    IndexName: "GSI3",
    KeyConditionExpression: keyCondition,
    ExpressionAttributeValues: values,
    ScanIndexForward: scanIndexForward
  };
  if (Object.keys(names).length) params.ExpressionAttributeNames = names;
  if (limit !== void 0) params.Limit = limit;
  if (exclusiveStartKey !== void 0) params.ExclusiveStartKey = exclusiveStartKey;
  if (filterExpression) params.FilterExpression = filterExpression;
  if (select) params.Select = select;
  const { Items, LastEvaluatedKey, Count } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return { items: Items ?? [], lastEvaluatedKey: LastEvaluatedKey ?? null, count: Count };
}

// shared/ses.js
var import_client_ses = require("@aws-sdk/client-ses");
var client2 = new import_client_ses.SESClient({});
async function sendMail({ to, subject, html }) {
  const fromEmail = process.env.SES_FROM_EMAIL;
  if (!fromEmail) throw new Error("SES_FROM_EMAIL env var is not set");
  await client2.send(new import_client_ses.SendEmailCommand({
    Source: fromEmail,
    Destination: { ToAddresses: [to] },
    Message: {
      Subject: { Data: subject, Charset: "UTF-8" },
      Body: { Html: { Data: html, Charset: "UTF-8" } }
    }
  }));
}

// shared/email-template.js
function wrapEmailHtml(bodyHtml) {
  return `<!DOCTYPE html><html lang="nl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f4f7fb;font-family:'Segoe UI',Arial,Helvetica,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f7fb;padding:32px 16px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;padding:40px;max-width:600px;">
<tr><td>
<div style="margin-bottom:28px;padding-bottom:20px;border-bottom:1px solid #e2e8f0;">
<span style="font-size:20px;font-weight:700;color:#2080b8;letter-spacing:-0.5px;">wieDoetHet</span>
</div>
<div style="font-size:15px;line-height:1.7;color:#1e293b;">${bodyHtml}</div>
<div style="margin-top:32px;padding-top:24px;border-top:1px solid #e2e8f0;">
<p style="margin:0;font-size:13px;color:#64748b;">Dit bericht is verstuurd via <a href="https://wiedoethet.nl" style="color:#2080b8;text-decoration:none;">wiedoethet.nl</a></p>
</div>
</td></tr>
</table>
</td></tr>
</table>
</body></html>`;
}

// wiedoethet-admin/index.js
var MAX_INTERNAL_QUERIES = 5;
var MAX_MAIL_RESOLVE_QUERIES = 200;
var MAX_MAIL_RECIPIENTS = 500;
var MAIL_SEND_CONCURRENCY = 5;
async function getStats(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const sevenDaysAgoIso = new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3).toISOString();
  const [totalUsers, totalGroups, newUsers, newGroups, recentUsersRaw, recentGroupsRaw] = await Promise.all([
    queryGsi3("USER", { select: "COUNT" }),
    queryGsi3("GROUP", { select: "COUNT" }),
    queryGsi3("USER", { skGte: sevenDaysAgoIso, select: "COUNT" }),
    queryGsi3("GROUP", { skGte: sevenDaysAgoIso, select: "COUNT" }),
    queryGsi3("USER", { scanIndexForward: false, limit: 5 }),
    queryGsi3("GROUP", { scanIndexForward: false, limit: 5 })
  ]);
  const [recentUsers, recentGroups] = await Promise.all([
    Promise.all(recentUsersRaw.items.map((u) => enrichUserSummary(u))),
    Promise.all(recentGroupsRaw.items.map(async (g) => {
      const initiator = await getItem(`USER#${g.initiatorId}`, "PROFILE");
      return enrichGroupSummary(g, initiator);
    }))
  ]);
  const stats = {
    totalUsers: totalUsers.count,
    totalGroups: totalGroups.count,
    newUsersLast7d: newUsers.count,
    newGroupsLast7d: newGroups.count,
    recentUsers,
    recentGroups,
    generatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  logSuccess({ route: "GET /admin/stats", adminUserId: admin.id, start, resultCount: recentUsers.length + recentGroups.length });
  return ok(stats);
}
async function listUsers(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const params = parseListParams(event);
  if (params.error) return params.error;
  const { limit, exclusiveStartKey, q } = params;
  const filterExpression = q ? "contains(email, :q) OR contains(#name, :q)" : void 0;
  const expressionAttributeNames = q ? { "#name": "name" } : void 0;
  const expressionAttributeValues = q ? { ":q": q } : void 0;
  const [{ items: rawUsers, nextCursor }, totalCount] = await Promise.all([
    queryGsi3Paginated("USER", { limit, exclusiveStartKey, filterExpression, expressionAttributeNames, expressionAttributeValues }),
    countAllMatchingUsers(q)
  ]);
  const items = await Promise.all(rawUsers.map((u) => enrichUserSummary(u)));
  logSuccess({ route: "GET /admin/users", adminUserId: admin.id, start, resultCount: items.length });
  return ok({ items, nextCursor, totalCount });
}
async function countAllMatchingUsers(q) {
  if (!q) {
    const result = await queryGsi3("USER", { select: "COUNT" });
    return result.count;
  }
  let total = 0;
  let exclusiveStartKey;
  for (let loop = 0; loop < MAX_MAIL_RESOLVE_QUERIES; loop++) {
    const result = await queryGsi3("USER", {
      limit: 50,
      exclusiveStartKey,
      filterExpression: "contains(email, :q) OR contains(#name, :q)",
      expressionAttributeNames: { "#name": "name" },
      expressionAttributeValues: { ":q": q }
    });
    total += result.items.length;
    if (!result.lastEvaluatedKey) break;
    exclusiveStartKey = result.lastEvaluatedKey;
  }
  return total;
}
async function mailUsers(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const body = parseBody(event);
  const subject = body.subject?.trim();
  const html = body.html?.trim();
  if (!subject) return badRequest("Onderwerp is verplicht");
  if (!html) return badRequest("Berichttekst is verplicht");
  let recipients;
  if (body.selectAll === true) {
    const q = typeof body.q === "string" ? body.q.trim() || void 0 : void 0;
    recipients = await resolveAllMatchingUsers(q);
  } else {
    if (!Array.isArray(body.userIds) || body.userIds.length === 0) {
      return badRequest("userIds is verplicht (of selectAll: true)");
    }
    const uniqueIds = [...new Set(body.userIds)];
    const found = await Promise.all(uniqueIds.map((id) => getItem(`USER#${id}`, "PROFILE")));
    recipients = found.filter(Boolean);
  }
  if (recipients.length === 0) return badRequest("Geen ontvangers gevonden");
  if (recipients.length > MAX_MAIL_RECIPIENTS) {
    return badRequest(`Te veel ontvangers (${recipients.length}). Maximum is ${MAX_MAIL_RECIPIENTS} per verzending.`);
  }
  const { sent, failed, failures } = await sendToRecipients(recipients, subject, wrapEmailHtml(html));
  logSuccess({ route: "POST /admin/mail", adminUserId: admin.id, start, resultCount: sent });
  return ok({ sent, failed, failures });
}
async function resolveAllMatchingUsers(q) {
  const users = [];
  let exclusiveStartKey;
  for (let loop = 0; loop < MAX_MAIL_RESOLVE_QUERIES; loop++) {
    const result = await queryGsi3("USER", {
      limit: 50,
      exclusiveStartKey,
      filterExpression: q ? "contains(email, :q) OR contains(#name, :q)" : void 0,
      expressionAttributeNames: q ? { "#name": "name" } : void 0,
      expressionAttributeValues: q ? { ":q": q } : void 0
    });
    users.push(...result.items);
    if (!result.lastEvaluatedKey) break;
    exclusiveStartKey = result.lastEvaluatedKey;
  }
  return users;
}
async function sendToRecipients(recipients, subject, html) {
  let sent = 0;
  const failures = [];
  for (let i = 0; i < recipients.length; i += MAIL_SEND_CONCURRENCY) {
    const chunk = recipients.slice(i, i + MAIL_SEND_CONCURRENCY);
    const results = await Promise.all(chunk.map(async (user) => {
      try {
        await sendMail({ to: user.email, subject, html });
        return { ok: true };
      } catch (err) {
        return { ok: false, userId: user.id, email: user.email, message: err.message };
      }
    }));
    for (const result of results) {
      if (result.ok) sent++;
      else failures.push({ userId: result.userId, email: result.email, message: result.message });
    }
  }
  return { sent, failed: failures.length, failures };
}
async function getUserDetail(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const { userId } = event.pathParameters ?? {};
  const user = await getItem(`USER#${userId}`, "PROFILE");
  if (!user) return notFound("Gebruiker niet gevonden");
  const groupItems = (await queryGsi2(`INITIATOR#${userId}`, "GROUP#")).filter((g) => g.SK === "METADATA");
  const groupCount = groupItems.length;
  const mostRecentGroupCreatedAt = groupItems.reduce((max, g) => g.createdAt > max ? g.createdAt : max, "");
  const lastActivityAt = mostRecentGroupCreatedAt > user.createdAt ? mostRecentGroupCreatedAt : user.createdAt;
  const groups = groupItems.map((g) => ({ id: g.id, name: g.name, shareToken: g.shareToken, createdAt: g.createdAt })).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const detail = { ...toUserSummaryBase(user), groupCount, lastActivityAt, groups };
  logSuccess({ route: "GET /admin/users/{userId}", adminUserId: admin.id, start, resultCount: 1 });
  return ok(detail);
}
async function listGroups(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const params = parseListParams(event);
  if (params.error) return params.error;
  const { limit, exclusiveStartKey, q } = params;
  const { items: rawGroups, nextCursor } = await queryGsi3Paginated("GROUP", {
    limit,
    exclusiveStartKey,
    filterExpression: q ? "contains(#name, :q)" : void 0,
    expressionAttributeNames: q ? { "#name": "name" } : void 0,
    expressionAttributeValues: q ? { ":q": q } : void 0
  });
  const uniqueInitiatorIds = [...new Set(rawGroups.map((g) => g.initiatorId))];
  const initiatorRecords = await Promise.all(uniqueInitiatorIds.map((id) => getItem(`USER#${id}`, "PROFILE")));
  const initiatorMap = new Map(initiatorRecords.filter(Boolean).map((u) => [u.id, u]));
  const items = await Promise.all(rawGroups.map((g) => enrichGroupSummary(g, initiatorMap.get(g.initiatorId))));
  logSuccess({ route: "GET /admin/groups", adminUserId: admin.id, start, resultCount: items.length });
  return ok({ items, nextCursor });
}
async function getGroupDetail(event) {
  const start = Date.now();
  const { user: admin, error } = await requireAdmin(event);
  if (error) return error;
  const { groupId } = event.pathParameters ?? {};
  const group = await getItem(`GROUP#${groupId}`, "METADATA");
  if (!group) return notFound("Groep niet gevonden");
  const [initiator, tasks, claims] = await Promise.all([
    getItem(`USER#${group.initiatorId}`, "PROFILE"),
    queryByPk(`GROUP#${groupId}`, "TASK#"),
    queryGsi1(`GCLAIM#${groupId}`)
  ]);
  const claimsByTask = /* @__PURE__ */ new Map();
  for (const c of claims) {
    if (!claimsByTask.has(c.taskId)) claimsByTask.set(c.taskId, []);
    claimsByTask.get(c.taskId).push(c);
  }
  const uniqueClaimers = new Set(claims.map((c) => c.userId ?? c.sessionId));
  const userIds = [...new Set(claims.map((c) => c.userId).filter(Boolean))];
  const userRecords = await Promise.all(userIds.map((uid) => getItem(`USER#${uid}`, "PROFILE")));
  const userMap = Object.fromEntries(userRecords.filter(Boolean).map((u) => [u.id, u.name]));
  const claimerName = (c) => c.userId ? userMap[c.userId] ?? "Onbekend" : c.anonymousName ?? "Anoniem";
  const taskList = tasks.map((t) => {
    const taskClaims = claimsByTask.get(t.id) ?? [];
    return {
      id: t.id,
      title: t.title,
      order: t.order,
      claimCount: taskClaims.length,
      claimedBy: taskClaims.length ? taskClaims.map(claimerName).join(", ") : null
    };
  }).sort((a, b) => a.order - b.order);
  const detail = {
    ...toGroupSummaryBase(group, initiator),
    taskCount: tasks.length,
    memberCount: uniqueClaimers.size,
    tasks: taskList
  };
  logSuccess({ route: "GET /admin/groups/{groupId}", adminUserId: admin.id, start, resultCount: 1 });
  return ok(detail);
}
function toUserSummaryBase(user) {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role ?? "user",
    createdAt: user.createdAt
  };
}
async function enrichUserSummary(user) {
  const groups = (await queryGsi2(`INITIATOR#${user.id}`, "GROUP#")).filter((g) => g.SK === "METADATA");
  const mostRecentGroupCreatedAt = groups.reduce((max, g) => g.createdAt > max ? g.createdAt : max, "");
  const lastActivityAt = mostRecentGroupCreatedAt > user.createdAt ? mostRecentGroupCreatedAt : user.createdAt;
  return { ...toUserSummaryBase(user), groupCount: groups.length, lastActivityAt };
}
function toGroupSummaryBase(group, initiator) {
  return {
    id: group.id,
    name: group.name,
    pictureUrl: group.pictureUrl ?? null,
    shareToken: group.shareToken,
    scorecardVisibility: group.scorecardVisibility,
    initiatorId: group.initiatorId,
    initiatorName: initiator?.name ?? "Onbekend",
    initiatorEmail: initiator?.email ?? "",
    createdAt: group.createdAt
  };
}
async function enrichGroupSummary(group, initiator) {
  const [tasks, claims] = await Promise.all([
    queryByPk(`GROUP#${group.id}`, "TASK#"),
    queryGsi1(`GCLAIM#${group.id}`)
  ]);
  const uniqueClaimers = new Set(claims.map((c) => c.userId ?? c.sessionId));
  return { ...toGroupSummaryBase(group, initiator), taskCount: tasks.length, memberCount: uniqueClaimers.size };
}
async function queryGsi3Paginated(gsi3pk, { limit, exclusiveStartKey, filterExpression, expressionAttributeNames, expressionAttributeValues }) {
  const items = [];
  let cursor = exclusiveStartKey;
  let lastEvaluatedKey = null;
  for (let loop = 0; loop < MAX_INTERNAL_QUERIES && items.length < limit; loop++) {
    const result = await queryGsi3(gsi3pk, {
      scanIndexForward: false,
      limit,
      exclusiveStartKey: cursor,
      filterExpression,
      expressionAttributeNames,
      expressionAttributeValues
    });
    items.push(...result.items);
    lastEvaluatedKey = result.lastEvaluatedKey;
    cursor = result.lastEvaluatedKey ?? void 0;
    if (!result.lastEvaluatedKey) break;
  }
  if (items.length > limit) {
    const trimmed = items.slice(0, limit);
    const lastReturned = trimmed[trimmed.length - 1];
    return { items: trimmed, nextCursor: encodeCursor(exclusiveStartKeyFromItem(lastReturned)) };
  }
  return { items, nextCursor: lastEvaluatedKey ? encodeCursor(lastEvaluatedKey) : null };
}
function exclusiveStartKeyFromItem(item) {
  return { PK: item.PK, SK: item.SK, GSI3PK: item.GSI3PK, GSI3SK: item.GSI3SK };
}
function encodeCursor(lastEvaluatedKey) {
  return lastEvaluatedKey ? Buffer.from(JSON.stringify(lastEvaluatedKey)).toString("base64url") : null;
}
function decodeCursor(cursor) {
  try {
    return JSON.parse(Buffer.from(cursor, "base64url").toString("utf8"));
  } catch {
    return void 0;
  }
}
function parseListParams(event) {
  const qs = event.queryStringParameters ?? {};
  let limit = 20;
  if (qs.limit !== void 0 && qs.limit !== "") {
    const n = Number(qs.limit);
    if (!Number.isInteger(n) || n < 1 || n > 50) {
      return { error: badRequest("limit moet een geheel getal tussen 1 en 50 zijn") };
    }
    limit = n;
  }
  let exclusiveStartKey;
  if (qs.cursor) {
    exclusiveStartKey = decodeCursor(qs.cursor);
    if (exclusiveStartKey === void 0) return { error: badRequest("Ongeldige cursor") };
  }
  const q = qs.q?.trim() || void 0;
  return { limit, exclusiveStartKey, q };
}
async function requireAdmin(event) {
  const token = extractBearer(event);
  if (!token) return { error: unauthorized() };
  let payload;
  try {
    payload = verifyJwt(token);
  } catch {
    return { error: unauthorized() };
  }
  const user = await getItem(`USER#${payload.sub}`, "PROFILE");
  if (!user) return { error: unauthorized() };
  if (user.role !== "admin") return { error: forbidden() };
  return { user };
}
function logSuccess({ route, adminUserId, start, resultCount }) {
  console.log(JSON.stringify({
    level: "info",
    route,
    adminUserId,
    durationMs: Date.now() - start,
    resultCount
  }));
}
var handler = async (event) => {
  process.env.TABLE_NAME = event.stageVariables?.tableName ?? process.env.TABLE_NAME ?? "wdh-main";
  try {
    const method = event.httpMethod;
    const path = event.path?.replace(/\/$/, "");
    if (method === "OPTIONS") return { statusCode: 204, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type,Authorization", "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS" }, body: "" };
    if (method === "GET" && path === "/admin/stats") return await getStats(event);
    if (method === "GET" && path === "/admin/users") return await listUsers(event);
    if (method === "GET" && /^\/admin\/users\/[^/]+$/.test(path)) return await getUserDetail(event);
    if (method === "GET" && path === "/admin/groups") return await listGroups(event);
    if (method === "GET" && /^\/admin\/groups\/[^/]+$/.test(path)) return await getGroupDetail(event);
    if (method === "POST" && path === "/admin/mail") return await mailUsers(event);
    return { statusCode: 404, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: "Route niet gevonden" }) };
  } catch (err) {
    return serverError(err);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
