var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// wiedoethet-auth/index.js
var index_exports = {};
__export(index_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(index_exports);
var import_node_crypto3 = require("node:crypto");

// shared/http.js
var CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS"
};
function ok(data) {
  return { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify(data) };
}
function created(data) {
  return { statusCode: 201, headers: CORS_HEADERS, body: JSON.stringify(data) };
}
function badRequest(message = "Ongeldig verzoek") {
  return { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function unauthorized(message = "Niet ingelogd") {
  return { statusCode: 401, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function conflict(message = "Conflict") {
  return { statusCode: 409, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function serverError(err) {
  console.error(err);
  return {
    statusCode: 500,
    headers: CORS_HEADERS,
    body: JSON.stringify({ message: "Interne serverfout" })
  };
}
function parseBody(event) {
  try {
    return event.body ? JSON.parse(event.body) : {};
  } catch {
    return {};
  }
}
function extractBearer(event) {
  const auth = event.headers?.Authorization ?? event.headers?.authorization ?? "";
  const token = auth.replace(/^Bearer\s+/i, "");
  return token || null;
}

// shared/jwt.js
var import_node_crypto = require("node:crypto");
var SECRET = process.env.JWT_SECRET;
var EXPIRES_SEC = Number(process.env.JWT_EXPIRES_SEC ?? 2592e3);
function b64url(str) {
  return Buffer.from(str).toString("base64url");
}
function b64urlDecode(str) {
  return Buffer.from(str, "base64url").toString("utf8");
}
function sign(header, body) {
  return (0, import_node_crypto.createHmac)("sha256", SECRET).update(`${header}.${body}`).digest("base64url");
}
function signJwt(payload) {
  if (!SECRET) throw new Error("JWT_SECRET env var is not set");
  const header = b64url(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const exp = Math.floor(Date.now() / 1e3) + EXPIRES_SEC;
  const body = b64url(JSON.stringify({ ...payload, exp, iat: Math.floor(Date.now() / 1e3) }));
  const sig = sign(header, body);
  return `${header}.${body}.${sig}`;
}
function verifyJwt(token) {
  if (!SECRET) throw new Error("JWT_SECRET env var is not set");
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Malformed token");
  const [header, body, sig] = parts;
  const expected = sign(header, body);
  if (sig.length !== expected.length) throw new Error("Invalid signature");
  let diff = 0;
  for (let i = 0; i < sig.length; i++) diff |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
  if (diff !== 0) throw new Error("Invalid signature");
  const payload = JSON.parse(b64urlDecode(body));
  if (payload.exp < Math.floor(Date.now() / 1e3)) throw new Error("Token expired");
  return payload;
}

// shared/password.js
var import_node_crypto2 = require("node:crypto");
var import_node_util = require("node:util");
var scryptAsync = (0, import_node_util.promisify)(import_node_crypto2.scrypt);
var SALT_BYTES = 16;
var KEY_LEN = 64;
var SCRYPT_PARAMS = { N: 16384, r: 8, p: 1 };
async function hashPassword(password) {
  const salt = (0, import_node_crypto2.randomBytes)(SALT_BYTES).toString("hex");
  const key = await scryptAsync(password, salt, KEY_LEN, SCRYPT_PARAMS);
  return `${salt}:${key.toString("hex")}`;
}
async function verifyPassword(password, hash) {
  const [salt, storedKey] = hash.split(":");
  const key = await scryptAsync(password, salt, KEY_LEN, SCRYPT_PARAMS);
  return (0, import_node_crypto2.timingSafeEqual)(Buffer.from(storedKey, "hex"), key);
}

// shared/db.js
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var client = new import_client_dynamodb.DynamoDBClient({});
var ddb = import_lib_dynamodb.DynamoDBDocumentClient.from(client, {
  marshallOptions: { removeUndefinedValues: true }
});
var table = () => process.env.TABLE_NAME ?? "wdh-main";
var keys = {
  user: (id) => ({ PK: `USER#${id}`, SK: "PROFILE" }),
  userByEmail: (email) => ({ GSI1PK: `EMAIL#${email}`, GSI1SK: "USER" }),
  group: (id) => ({ PK: `GROUP#${id}`, SK: "METADATA" }),
  groupByShareToken: (token) => ({ GSI1PK: `SHARE#${token}`, GSI1SK: "GROUP" }),
  groupsByInitiator: (userId) => ({ GSI2PK: `INITIATOR#${userId}`, GSI2SK: `GROUP#` }),
  task: (groupId, order, taskId) => ({
    PK: `GROUP#${groupId}`,
    SK: `TASK#${String(order).padStart(5, "0")}#${taskId}`
  }),
  tasksInGroup: (groupId) => ({ PK: `GROUP#${groupId}`, SKPrefix: "TASK#" }),
  claim: (taskId, claimId) => ({ PK: `TASK#${taskId}`, SK: `CLAIM#${claimId}` }),
  claimsOnTask: (taskId) => ({ PK: `TASK#${taskId}`, SKPrefix: "CLAIM#" }),
  claimsByGroup: (groupId) => ({ GSI1PK: `GCLAIM#${groupId}` }),
  // GSI3 — Admin Section (wiedoethet-admin): "list all users/groups" without a table Scan.
  userGsi3: (createdAt, id) => ({ GSI3PK: "USER", GSI3SK: `${createdAt}#${id}` }),
  groupGsi3: (createdAt, id) => ({ GSI3PK: "GROUP", GSI3SK: `${createdAt}#${id}` })
};
async function getItem(pk, sk) {
  const { Item } = await ddb.send(new import_lib_dynamodb.GetCommand({ TableName: table(), Key: { PK: pk, SK: sk } }));
  return Item ?? null;
}
async function putItem(item) {
  await ddb.send(new import_lib_dynamodb.PutCommand({ TableName: table(), Item: item }));
  return item;
}
async function updateItem(pk, sk, updates) {
  const expressions = [];
  const names = {};
  const values = {};
  for (const [key, val] of Object.entries(updates)) {
    expressions.push(`#${key} = :${key}`);
    names[`#${key}`] = key;
    values[`:${key}`] = val;
  }
  await ddb.send(new import_lib_dynamodb.UpdateCommand({
    TableName: table(),
    Key: { PK: pk, SK: sk },
    UpdateExpression: `SET ${expressions.join(", ")}`,
    ExpressionAttributeNames: names,
    ExpressionAttributeValues: values
  }));
}
async function queryGsi1(gsi1pk, gsi1skPrefix = null) {
  const params = {
    TableName: table(),
    IndexName: "GSI1",
    KeyConditionExpression: gsi1skPrefix ? "GSI1PK = :pk AND begins_with(GSI1SK, :prefix)" : "GSI1PK = :pk",
    ExpressionAttributeValues: gsi1skPrefix ? { ":pk": gsi1pk, ":prefix": gsi1skPrefix } : { ":pk": gsi1pk }
  };
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}

// wiedoethet-auth/index.js
async function login(event) {
  const { email, password } = parseBody(event);
  if (!email || !password) return badRequest("E-mailadres en wachtwoord zijn verplicht");
  const [userRecord] = await queryGsi1(`EMAIL#${email.toLowerCase()}`);
  if (!userRecord) return unauthorized("Ongeldig e-mailadres of wachtwoord");
  const valid = await verifyPassword(password, userRecord.passwordHash);
  if (!valid) return unauthorized("Ongeldig e-mailadres of wachtwoord");
  const token = signJwt({ sub: userRecord.id, email: userRecord.email });
  return ok({ token, user: safeUser(userRecord) });
}
async function register(event) {
  const { name, email, password } = parseBody(event);
  if (!name) return badRequest("Naam is verplicht");
  if (!email) return badRequest("E-mailadres is verplicht");
  if (!password || password.length < 8) return badRequest("Wachtwoord moet minimaal 8 tekens bevatten");
  const emailLower = email.toLowerCase();
  const [existing] = await queryGsi1(`EMAIL#${emailLower}`);
  if (existing) return conflict("E-mailadres al in gebruik");
  const id = (0, import_node_crypto3.randomUUID)();
  const passwordHash = await hashPassword(password);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const user = {
    PK: `USER#${id}`,
    SK: "PROFILE",
    GSI1PK: `EMAIL#${emailLower}`,
    GSI1SK: "USER",
    ...keys.userGsi3(now, id),
    id,
    name,
    email: emailLower,
    passwordHash,
    avatarUrl: null,
    createdAt: now
  };
  await putItem(user);
  const token = signJwt({ sub: id, email: emailLower });
  return created({ token, user: safeUser(user) });
}
async function me(event) {
  const jwtPayload = requireAuth(event);
  if (!jwtPayload) return unauthorized();
  const user = await getItem(`USER#${jwtPayload.sub}`, "PROFILE");
  if (!user) return unauthorized();
  return ok(safeUser(user));
}
async function updateProfile(event) {
  const jwtPayload = requireAuth(event);
  if (!jwtPayload) return unauthorized();
  const { phoneNumber } = parseBody(event);
  if (phoneNumber !== null && phoneNumber !== void 0) {
    if (typeof phoneNumber !== "string" || !/^\+[1-9]\d{7,14}$/.test(phoneNumber)) {
      return badRequest("Voer een geldig telefoonnummer in E.164-formaat in (bijv. +31612345678)");
    }
  }
  await updateItem(`USER#${jwtPayload.sub}`, "PROFILE", { phoneNumber: phoneNumber ?? null });
  const user = await getItem(`USER#${jwtPayload.sub}`, "PROFILE");
  return ok(safeUser(user));
}
function safeUser(u) {
  const { PK, SK, GSI1PK, GSI1SK, GSI3PK, GSI3SK, passwordHash, ...rest } = u;
  return rest;
}
function requireAuth(event) {
  const token = extractBearer(event);
  if (!token) return null;
  try {
    return verifyJwt(token);
  } catch {
    return null;
  }
}
var handler = async (event) => {
  process.env.TABLE_NAME = event.stageVariables?.tableName ?? process.env.TABLE_NAME ?? "wdh-main";
  try {
    const method = event.httpMethod;
    const path = event.path?.replace(/\/$/, "");
    if (method === "OPTIONS") return { statusCode: 204, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type,Authorization", "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS" }, body: "" };
    if (method === "POST" && path === "/auth/login") return await login(event);
    if (method === "POST" && path === "/auth/register") return await register(event);
    if (method === "GET" && path === "/auth/me") return await me(event);
    if (method === "PATCH" && path === "/auth/profile") return await updateProfile(event);
    return { statusCode: 404, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: "Route niet gevonden" }) };
  } catch (err) {
    return serverError(err);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
