var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// wiedoethet-reminders/index.js
var index_exports = {};
__export(index_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(index_exports);

// shared/http.js
var CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS"
};
function ok(data) {
  return { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify(data) };
}
function created(data) {
  return { statusCode: 201, headers: CORS_HEADERS, body: JSON.stringify(data) };
}
function noContent() {
  return { statusCode: 204, headers: CORS_HEADERS, body: "" };
}
function badRequest(message = "Ongeldig verzoek") {
  return { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function unauthorized(message = "Niet ingelogd") {
  return { statusCode: 401, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function forbidden(message = "Geen toegang") {
  return { statusCode: 403, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function notFound(message = "Niet gevonden") {
  return { statusCode: 404, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function serverError(err) {
  console.error(err);
  return {
    statusCode: 500,
    headers: CORS_HEADERS,
    body: JSON.stringify({ message: "Interne serverfout" })
  };
}
function parseBody(event) {
  try {
    return event.body ? JSON.parse(event.body) : {};
  } catch {
    return {};
  }
}
function extractBearer(event) {
  const auth = event.headers?.Authorization ?? event.headers?.authorization ?? "";
  const token = auth.replace(/^Bearer\s+/i, "");
  return token || null;
}

// shared/jwt.js
var import_node_crypto = require("node:crypto");
var SECRET = process.env.JWT_SECRET;
var EXPIRES_SEC = Number(process.env.JWT_EXPIRES_SEC ?? 2592e3);
function b64urlDecode(str) {
  return Buffer.from(str, "base64url").toString("utf8");
}
function sign(header, body) {
  return (0, import_node_crypto.createHmac)("sha256", SECRET).update(`${header}.${body}`).digest("base64url");
}
function verifyJwt(token) {
  if (!SECRET) throw new Error("JWT_SECRET env var is not set");
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Malformed token");
  const [header, body, sig] = parts;
  const expected = sign(header, body);
  if (sig.length !== expected.length) throw new Error("Invalid signature");
  let diff = 0;
  for (let i = 0; i < sig.length; i++) diff |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
  if (diff !== 0) throw new Error("Invalid signature");
  const payload = JSON.parse(b64urlDecode(body));
  if (payload.exp < Math.floor(Date.now() / 1e3)) throw new Error("Token expired");
  return payload;
}

// shared/db.js
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var client = new import_client_dynamodb.DynamoDBClient({});
var ddb = import_lib_dynamodb.DynamoDBDocumentClient.from(client, {
  marshallOptions: { removeUndefinedValues: true }
});
var table = () => process.env.TABLE_NAME ?? "wdh-main";
async function getItem(pk, sk) {
  const { Item } = await ddb.send(new import_lib_dynamodb.GetCommand({ TableName: table(), Key: { PK: pk, SK: sk } }));
  return Item ?? null;
}
async function putItem(item) {
  await ddb.send(new import_lib_dynamodb.PutCommand({ TableName: table(), Item: item }));
  return item;
}
async function deleteItem(pk, sk) {
  await ddb.send(new import_lib_dynamodb.DeleteCommand({ TableName: table(), Key: { PK: pk, SK: sk } }));
}
async function queryByPk(pk, skPrefix = null, indexName = null) {
  const params = {
    TableName: table(),
    KeyConditionExpression: skPrefix ? "PK = :pk AND begins_with(SK, :prefix)" : "PK = :pk",
    ExpressionAttributeValues: skPrefix ? { ":pk": pk, ":prefix": skPrefix } : { ":pk": pk }
  };
  if (indexName) {
    params.IndexName = indexName;
    params.KeyConditionExpression = params.KeyConditionExpression.replace(/\bPK\b/g, indexName === "GSI1" ? "GSI1PK" : "GSI2PK").replace(/\bSK\b/g, indexName === "GSI1" ? "GSI1SK" : "GSI2SK");
  }
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}

// shared/eventbridge.js
var import_client_eventbridge = require("@aws-sdk/client-eventbridge");
var eb = new import_client_eventbridge.EventBridgeClient({ region: process.env.AWS_REGION ?? "eu-west-2" });
var FIRE_LAMBDA_ARN = process.env.REMINDER_FIRE_LAMBDA_ARN;
var TARGET_ID = "ReminderFireTarget";
async function scheduleOneTimeRule(ruleName, scheduledAt, inputPayload) {
  if (!FIRE_LAMBDA_ARN) throw new Error("REMINDER_FIRE_LAMBDA_ARN env var is not set");
  const atExpr = `at(${scheduledAt.slice(0, 19)})`;
  const { RuleArn } = await eb.send(
    new import_client_eventbridge.PutRuleCommand({
      Name: ruleName,
      ScheduleExpression: atExpr,
      State: "ENABLED"
    })
  );
  await eb.send(
    new import_client_eventbridge.PutTargetsCommand({
      Rule: ruleName,
      Targets: [
        {
          Id: TARGET_ID,
          Arn: FIRE_LAMBDA_ARN,
          Input: JSON.stringify(inputPayload)
        }
      ]
    })
  );
  return RuleArn;
}
async function deleteRule(ruleName) {
  try {
    await eb.send(new import_client_eventbridge.RemoveTargetsCommand({ Rule: ruleName, Ids: [TARGET_ID] }));
    await eb.send(new import_client_eventbridge.DeleteRuleCommand({ Name: ruleName }));
  } catch (err) {
    if (err.name !== "ResourceNotFoundException") throw err;
  }
}

// wiedoethet-reminders/index.js
function requireAuth(event) {
  const token = extractBearer(event);
  if (!token) return null;
  try {
    return verifyJwt(token);
  } catch {
    return null;
  }
}
function stripKeys(item) {
  const { PK, SK, GSI1PK, GSI1SK, ...rest } = item;
  return rest;
}
function buildRuleName(scope, id) {
  return `wdh-reminder-${scope}-${id}`;
}
async function scheduleReminder(event) {
  const user = requireAuth(event);
  if (!user) return unauthorized();
  const body = parseBody(event);
  const { scope, id, scheduledAt, groupId } = body;
  if (!scope || !["task", "group"].includes(scope)) return badRequest('scope must be "task" or "group"');
  if (!id) return badRequest("id is verplicht");
  if (!scheduledAt) return badRequest("scheduledAt is verplicht");
  const scheduledDate = new Date(scheduledAt);
  if (isNaN(scheduledDate.getTime())) return badRequest("scheduledAt is geen geldige datum");
  if (scheduledDate <= /* @__PURE__ */ new Date()) return badRequest("scheduledAt moet in de toekomst liggen");
  let group;
  if (scope === "group") {
    group = await getItem(`GROUP#${id}`, "METADATA");
    if (!group) return notFound("Groep niet gevonden");
    if (group.initiatorId !== user.sub) return forbidden();
  } else {
    if (!groupId) return badRequest("groupId is verplicht voor task-herinneringen");
    group = await getItem(`GROUP#${groupId}`, "METADATA");
    if (!group) return notFound("Groep niet gevonden");
    if (group.initiatorId !== user.sub) return forbidden();
    const taskItems = await queryByPk(`GROUP#${groupId}`, "TASK#");
    const task = taskItems.find((t) => t.id === id);
    if (!task) return notFound("Taak niet gevonden");
  }
  const scopeGroupId = scope === "group" ? id : groupId;
  const ruleName = buildRuleName(scope, id);
  const scheduledAtIso = scheduledDate.toISOString();
  const existing = await getItem(`REMINDER#${scope}#${id}`, "REMINDER");
  if (existing?.ruleName) {
    await deleteRule(existing.ruleName);
  }
  await scheduleOneTimeRule(ruleName, scheduledAtIso, { ruleName });
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const reminder = {
    PK: `REMINDER#${scope}#${id}`,
    SK: "REMINDER",
    GSI1PK: `RULE#${ruleName}`,
    GSI1SK: "REMINDER",
    scope,
    scopeId: id,
    groupId: scopeGroupId,
    initiatorId: user.sub,
    scheduledAt: scheduledAtIso,
    ruleName,
    status: "scheduled",
    createdAt: now
  };
  await putItem(reminder);
  return created(stripKeys(reminder));
}
async function getReminder(event) {
  const user = requireAuth(event);
  if (!user) return unauthorized();
  const parts = event.path?.replace(/\/$/, "").split("/");
  const scope = parts[2];
  const id = parts[3];
  if (!scope || !id) return badRequest();
  const reminder = await getItem(`REMINDER#${scope}#${id}`, "REMINDER");
  if (!reminder) {
    return ok({ scope, id, scheduledAt: null, status: "none" });
  }
  if (reminder.initiatorId !== user.sub) return forbidden();
  return ok(stripKeys(reminder));
}
async function cancelReminder(event) {
  const user = requireAuth(event);
  if (!user) return unauthorized();
  const parts = event.path?.replace(/\/$/, "").split("/");
  const scope = parts[2];
  const id = parts[3];
  if (!scope || !id) return badRequest();
  const reminder = await getItem(`REMINDER#${scope}#${id}`, "REMINDER");
  if (!reminder) return notFound("Herinnering niet gevonden");
  if (reminder.initiatorId !== user.sub) return forbidden();
  await deleteRule(reminder.ruleName);
  await deleteItem(`REMINDER#${scope}#${id}`, "REMINDER");
  return noContent();
}
var handler = async (event) => {
  process.env.TABLE_NAME = event.stageVariables?.tableName ?? process.env.TABLE_NAME ?? "wdh-main";
  try {
    const method = event.httpMethod;
    const path = event.path?.replace(/\/$/, "");
    if (method === "OPTIONS") {
      return {
        statusCode: 204,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type,Authorization",
          "Access-Control-Allow-Methods": "GET,POST,DELETE,OPTIONS"
        },
        body: ""
      };
    }
    if (method === "POST" && path === "/reminders")
      return await scheduleReminder(event);
    if (method === "GET" && /^\/reminders\/(task|group)\/[^/]+$/.test(path))
      return await getReminder(event);
    if (method === "DELETE" && /^\/reminders\/(task|group)\/[^/]+$/.test(path))
      return await cancelReminder(event);
    return notFound("Route niet gevonden");
  } catch (err) {
    return serverError(err);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
