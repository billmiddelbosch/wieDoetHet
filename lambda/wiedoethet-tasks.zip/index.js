var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// wiedoethet-tasks/index.js
var index_exports = {};
__export(index_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(index_exports);
var import_node_crypto2 = require("node:crypto");

// shared/http.js
var CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS"
};
function ok(data) {
  return { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify(data) };
}
function created(data) {
  return { statusCode: 201, headers: CORS_HEADERS, body: JSON.stringify(data) };
}
function noContent() {
  return { statusCode: 204, headers: CORS_HEADERS, body: "" };
}
function badRequest(message = "Ongeldig verzoek") {
  return { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function unauthorized(message = "Niet ingelogd") {
  return { statusCode: 401, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function forbidden(message = "Geen toegang") {
  return { statusCode: 403, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function notFound(message = "Niet gevonden") {
  return { statusCode: 404, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function serverError(err) {
  console.error(err);
  return {
    statusCode: 500,
    headers: CORS_HEADERS,
    body: JSON.stringify({ message: "Interne serverfout" })
  };
}
function parseBody(event) {
  try {
    return event.body ? JSON.parse(event.body) : {};
  } catch {
    return {};
  }
}
function extractBearer(event) {
  const auth = event.headers?.Authorization ?? event.headers?.authorization ?? "";
  const token = auth.replace(/^Bearer\s+/i, "");
  return token || null;
}

// shared/jwt.js
var import_node_crypto = require("node:crypto");
var SECRET = process.env.JWT_SECRET;
var EXPIRES_SEC = Number(process.env.JWT_EXPIRES_SEC ?? 2592e3);
function b64urlDecode(str) {
  return Buffer.from(str, "base64url").toString("utf8");
}
function sign(header, body) {
  return (0, import_node_crypto.createHmac)("sha256", SECRET).update(`${header}.${body}`).digest("base64url");
}
function verifyJwt(token) {
  if (!SECRET) throw new Error("JWT_SECRET env var is not set");
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Malformed token");
  const [header, body, sig] = parts;
  const expected = sign(header, body);
  if (sig.length !== expected.length) throw new Error("Invalid signature");
  let diff = 0;
  for (let i = 0; i < sig.length; i++) diff |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
  if (diff !== 0) throw new Error("Invalid signature");
  const payload = JSON.parse(b64urlDecode(body));
  if (payload.exp < Math.floor(Date.now() / 1e3)) throw new Error("Token expired");
  return payload;
}

// shared/db.js
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var client = new import_client_dynamodb.DynamoDBClient({});
var ddb = import_lib_dynamodb.DynamoDBDocumentClient.from(client, {
  marshallOptions: { removeUndefinedValues: true }
});
var TABLE = process.env.TABLE_NAME ?? "wdh-main";
async function getItem(pk, sk) {
  const { Item } = await ddb.send(new import_lib_dynamodb.GetCommand({ TableName: TABLE, Key: { PK: pk, SK: sk } }));
  return Item ?? null;
}
async function putItem(item) {
  await ddb.send(new import_lib_dynamodb.PutCommand({ TableName: TABLE, Item: item }));
  return item;
}
async function deleteItem(pk, sk) {
  await ddb.send(new import_lib_dynamodb.DeleteCommand({ TableName: TABLE, Key: { PK: pk, SK: sk } }));
}
async function queryByPk(pk, skPrefix = null, indexName = null) {
  const params = {
    TableName: TABLE,
    KeyConditionExpression: skPrefix ? "PK = :pk AND begins_with(SK, :prefix)" : "PK = :pk",
    ExpressionAttributeValues: skPrefix ? { ":pk": pk, ":prefix": skPrefix } : { ":pk": pk }
  };
  if (indexName) {
    params.IndexName = indexName;
    params.KeyConditionExpression = params.KeyConditionExpression.replace(/\bPK\b/g, indexName === "GSI1" ? "GSI1PK" : "GSI2PK").replace(/\bSK\b/g, indexName === "GSI1" ? "GSI1SK" : "GSI2SK");
  }
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}

// wiedoethet-tasks/index.js
async function listTasks(event) {
  const { groupId } = event.pathParameters ?? {};
  const items = await queryByPk(`GROUP#${groupId}`, "TASK#");
  const tasks = items.map(stripKeys).sort((a, b) => a.order - b.order);
  return ok(tasks);
}
async function createTask(event) {
  const user = requireAuth(event);
  if (!user) return unauthorized();
  const { groupId } = event.pathParameters ?? {};
  const group = await getItem(`GROUP#${groupId}`, "METADATA");
  if (!group) return notFound("Groep niet gevonden");
  if (group.initiatorId !== user.sub) return forbidden();
  const body = parseBody(event);
  if (!body.title?.trim()) return badRequest("Titel is verplicht");
  const existingTasks = await queryByPk(`GROUP#${groupId}`, "TASK#");
  const order = existingTasks.length;
  const id = (0, import_node_crypto2.randomUUID)();
  const task = {
    PK: `GROUP#${groupId}`,
    SK: `TASK#${String(order).padStart(5, "0")}#${id}`,
    id,
    groupId,
    title: body.title.trim(),
    description: body.description ?? null,
    maxClaims: body.maxClaims ?? 1,
    order
  };
  await putItem(task);
  return created(stripKeys(task));
}
async function updateTask(event) {
  const user = requireAuth(event);
  if (!user) return unauthorized();
  const { groupId, taskId } = event.pathParameters ?? {};
  const group = await getItem(`GROUP#${groupId}`, "METADATA");
  if (!group) return notFound("Groep niet gevonden");
  if (group.initiatorId !== user.sub) return forbidden();
  const items = await queryByPk(`GROUP#${groupId}`, "TASK#");
  const task = items.find((t) => t.id === taskId);
  if (!task) return notFound("Taak niet gevonden");
  const body = parseBody(event);
  const updated = {
    ...task,
    title: body.title?.trim() ?? task.title,
    description: "description" in body ? body.description : task.description,
    maxClaims: body.maxClaims ?? task.maxClaims
  };
  await putItem(updated);
  return ok(stripKeys(updated));
}
async function deleteTask(event) {
  const user = requireAuth(event);
  if (!user) return unauthorized();
  const { groupId, taskId } = event.pathParameters ?? {};
  const group = await getItem(`GROUP#${groupId}`, "METADATA");
  if (!group) return notFound("Groep niet gevonden");
  if (group.initiatorId !== user.sub) return forbidden();
  const items = await queryByPk(`GROUP#${groupId}`, "TASK#");
  const task = items.find((t) => t.id === taskId);
  if (!task) return notFound("Taak niet gevonden");
  await deleteItem(task.PK, task.SK);
  return noContent();
}
function stripKeys(item) {
  const { PK, SK, GSI1PK, GSI1SK, GSI2PK, GSI2SK, ...rest } = item;
  return rest;
}
function requireAuth(event) {
  const token = extractBearer(event);
  if (!token) return null;
  try {
    return verifyJwt(token);
  } catch {
    return null;
  }
}
var handler = async (event) => {
  try {
    const method = event.httpMethod;
    const path = event.path?.replace(/\/$/, "");
    if (method === "OPTIONS") return { statusCode: 204, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type,Authorization", "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS" }, body: "" };
    if (method === "GET" && /^\/groups\/[^/]+\/tasks$/.test(path)) return await listTasks(event);
    if (method === "POST" && /^\/groups\/[^/]+\/tasks$/.test(path)) return await createTask(event);
    if (method === "PATCH" && /^\/groups\/[^/]+\/tasks\/[^/]+$/.test(path)) return await updateTask(event);
    if (method === "DELETE" && /^\/groups\/[^/]+\/tasks\/[^/]+$/.test(path)) return await deleteTask(event);
    return { statusCode: 404, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: "Route niet gevonden" }) };
  } catch (err) {
    return serverError(err);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
