var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// wiedoethet-groups/index.js
var index_exports = {};
__export(index_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(index_exports);
var import_node_crypto2 = require("node:crypto");

// shared/http.js
var CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS"
};
function ok(data) {
  return { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify(data) };
}
function created(data) {
  return { statusCode: 201, headers: CORS_HEADERS, body: JSON.stringify(data) };
}
function noContent() {
  return { statusCode: 204, headers: CORS_HEADERS, body: "" };
}
function badRequest(message = "Ongeldig verzoek") {
  return { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function unauthorized(message = "Niet ingelogd") {
  return { statusCode: 401, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function forbidden(message = "Geen toegang") {
  return { statusCode: 403, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function notFound(message = "Niet gevonden") {
  return { statusCode: 404, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function serverError(err) {
  console.error(err);
  return {
    statusCode: 500,
    headers: CORS_HEADERS,
    body: JSON.stringify({ message: "Interne serverfout" })
  };
}
function parseBody(event) {
  try {
    return event.body ? JSON.parse(event.body) : {};
  } catch {
    return {};
  }
}
function extractBearer(event) {
  const auth = event.headers?.Authorization ?? event.headers?.authorization ?? "";
  const token = auth.replace(/^Bearer\s+/i, "");
  return token || null;
}

// shared/jwt.js
var import_node_crypto = require("node:crypto");
var SECRET = process.env.JWT_SECRET;
var EXPIRES_SEC = Number(process.env.JWT_EXPIRES_SEC ?? 2592e3);
function b64urlDecode(str) {
  return Buffer.from(str, "base64url").toString("utf8");
}
function sign(header, body) {
  return (0, import_node_crypto.createHmac)("sha256", SECRET).update(`${header}.${body}`).digest("base64url");
}
function verifyJwt(token) {
  if (!SECRET) throw new Error("JWT_SECRET env var is not set");
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Malformed token");
  const [header, body, sig] = parts;
  const expected = sign(header, body);
  if (sig.length !== expected.length) throw new Error("Invalid signature");
  let diff = 0;
  for (let i = 0; i < sig.length; i++) diff |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
  if (diff !== 0) throw new Error("Invalid signature");
  const payload = JSON.parse(b64urlDecode(body));
  if (payload.exp < Math.floor(Date.now() / 1e3)) throw new Error("Token expired");
  return payload;
}

// shared/db.js
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var client = new import_client_dynamodb.DynamoDBClient({});
var ddb = import_lib_dynamodb.DynamoDBDocumentClient.from(client, {
  marshallOptions: { removeUndefinedValues: true }
});
var TABLE = process.env.TABLE_NAME ?? "wdh-main";
async function getItem(pk, sk) {
  const { Item } = await ddb.send(new import_lib_dynamodb.GetCommand({ TableName: TABLE, Key: { PK: pk, SK: sk } }));
  return Item ?? null;
}
async function putItem(item) {
  await ddb.send(new import_lib_dynamodb.PutCommand({ TableName: TABLE, Item: item }));
  return item;
}
async function deleteItem(pk, sk) {
  await ddb.send(new import_lib_dynamodb.DeleteCommand({ TableName: TABLE, Key: { PK: pk, SK: sk } }));
}
async function queryGsi1(gsi1pk, gsi1skPrefix = null) {
  const params = {
    TableName: TABLE,
    IndexName: "GSI1",
    KeyConditionExpression: gsi1skPrefix ? "GSI1PK = :pk AND begins_with(GSI1SK, :prefix)" : "GSI1PK = :pk",
    ExpressionAttributeValues: gsi1skPrefix ? { ":pk": gsi1pk, ":prefix": gsi1skPrefix } : { ":pk": gsi1pk }
  };
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}
async function queryGsi2(gsi2pk, gsi2skPrefix = null) {
  const params = {
    TableName: TABLE,
    IndexName: "GSI2",
    KeyConditionExpression: gsi2skPrefix ? "GSI2PK = :pk AND begins_with(GSI2SK, :prefix)" : "GSI2PK = :pk",
    ExpressionAttributeValues: gsi2skPrefix ? { ":pk": gsi2pk, ":prefix": gsi2skPrefix } : { ":pk": gsi2pk }
  };
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}

// wiedoethet-groups/index.js
async function listGroups(event) {
  const user = requireAuth(event);
  if (!user) return unauthorized();
  const items = await queryGsi2(`INITIATOR#${user.sub}`, "GROUP#");
  const groups = items.filter((i) => i.SK === "METADATA").map(stripKeys).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return ok(groups);
}
async function createGroup(event) {
  const user = requireAuth(event);
  if (!user) return unauthorized();
  const body = parseBody(event);
  if (!body.name?.trim()) return badRequest("Naam is verplicht");
  const id = (0, import_node_crypto2.randomUUID)();
  const shareToken = `tok-${(0, import_node_crypto2.randomUUID)().slice(0, 8)}`;
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const group = {
    PK: `GROUP#${id}`,
    SK: "METADATA",
    GSI1PK: `SHARE#${shareToken}`,
    GSI1SK: "GROUP",
    GSI2PK: `INITIATOR#${user.sub}`,
    GSI2SK: `GROUP#${id}`,
    id,
    name: body.name.trim(),
    pictureUrl: body.pictureUrl ?? null,
    shareToken,
    initiatorId: user.sub,
    requireTaskSelection: body.requireTaskSelection ?? true,
    scorecardVisibility: body.scorecardVisibility ?? "all",
    scorecardViewerIds: body.scorecardViewerIds ?? [],
    reminderAt: body.reminderAt ?? null,
    createdAt: now
  };
  await putItem(group);
  return created(stripKeys(group));
}
async function getGroupByShareToken(event) {
  const { shareToken } = event.pathParameters ?? {};
  if (!shareToken) return badRequest();
  const [group] = await queryGsi1(`SHARE#${shareToken}`);
  if (!group) return notFound("Groep niet gevonden");
  return ok(stripKeys(group));
}
async function getGroup(event) {
  const user = requireAuth(event);
  if (!user) return unauthorized();
  const { groupId: id } = event.pathParameters ?? {};
  const group = await getItem(`GROUP#${id}`, "METADATA");
  if (!group) return notFound("Groep niet gevonden");
  if (group.initiatorId !== user.sub) return forbidden();
  return ok(stripKeys(group));
}
async function updateGroup(event) {
  const user = requireAuth(event);
  if (!user) return unauthorized();
  const { groupId: id } = event.pathParameters ?? {};
  const group = await getItem(`GROUP#${id}`, "METADATA");
  if (!group) return notFound("Groep niet gevonden");
  if (group.initiatorId !== user.sub) return forbidden();
  const body = parseBody(event);
  const updated = {
    ...group,
    name: body.name?.trim() ?? group.name,
    pictureUrl: "pictureUrl" in body ? body.pictureUrl : group.pictureUrl,
    requireTaskSelection: "requireTaskSelection" in body ? body.requireTaskSelection : group.requireTaskSelection,
    scorecardVisibility: body.scorecardVisibility ?? group.scorecardVisibility,
    scorecardViewerIds: body.scorecardViewerIds ?? group.scorecardViewerIds,
    reminderAt: "reminderAt" in body ? body.reminderAt : group.reminderAt
  };
  await putItem(updated);
  return ok(stripKeys(updated));
}
async function deleteGroup(event) {
  const user = requireAuth(event);
  if (!user) return unauthorized();
  const { groupId: id } = event.pathParameters ?? {};
  const group = await getItem(`GROUP#${id}`, "METADATA");
  if (!group) return notFound("Groep niet gevonden");
  if (group.initiatorId !== user.sub) return forbidden();
  await deleteItem(`GROUP#${id}`, "METADATA");
  return noContent();
}
function stripKeys(item) {
  const { PK, SK, GSI1PK, GSI1SK, GSI2PK, GSI2SK, ...rest } = item;
  return rest;
}
function requireAuth(event) {
  const token = extractBearer(event);
  if (!token) return null;
  try {
    return verifyJwt(token);
  } catch {
    return null;
  }
}
var handler = async (event) => {
  try {
    const method = event.httpMethod;
    const path = event.path?.replace(/\/$/, "");
    if (method === "OPTIONS") return { statusCode: 204, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type,Authorization", "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS" }, body: "" };
    if (method === "GET" && path === "/groups") return await listGroups(event);
    if (method === "POST" && path === "/groups") return await createGroup(event);
    if (method === "GET" && path.startsWith("/groups/share/")) return await getGroupByShareToken(event);
    if (method === "GET" && /^\/groups\/[^/]+$/.test(path)) return await getGroup(event);
    if (method === "PATCH" && /^\/groups\/[^/]+$/.test(path)) return await updateGroup(event);
    if (method === "DELETE" && /^\/groups\/[^/]+$/.test(path)) return await deleteGroup(event);
    return { statusCode: 404, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: "Route niet gevonden" }) };
  } catch (err) {
    return serverError(err);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
