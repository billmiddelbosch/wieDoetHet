var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// wiedoethet-reminder-fire/index.js
var index_exports = {};
__export(index_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(index_exports);

// shared/db.js
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var client = new import_client_dynamodb.DynamoDBClient({});
var ddb = import_lib_dynamodb.DynamoDBDocumentClient.from(client, {
  marshallOptions: { removeUndefinedValues: true }
});
var table = () => process.env.TABLE_NAME ?? "wdh-main";
async function getItem(pk, sk) {
  const { Item } = await ddb.send(new import_lib_dynamodb.GetCommand({ TableName: table(), Key: { PK: pk, SK: sk } }));
  return Item ?? null;
}
async function updateItem(pk, sk, updates) {
  const expressions = [];
  const names = {};
  const values = {};
  for (const [key, val] of Object.entries(updates)) {
    expressions.push(`#${key} = :${key}`);
    names[`#${key}`] = key;
    values[`:${key}`] = val;
  }
  await ddb.send(new import_lib_dynamodb.UpdateCommand({
    TableName: table(),
    Key: { PK: pk, SK: sk },
    UpdateExpression: `SET ${expressions.join(", ")}`,
    ExpressionAttributeNames: names,
    ExpressionAttributeValues: values
  }));
}
async function queryByPk(pk, skPrefix = null, indexName = null) {
  const params = {
    TableName: table(),
    KeyConditionExpression: skPrefix ? "PK = :pk AND begins_with(SK, :prefix)" : "PK = :pk",
    ExpressionAttributeValues: skPrefix ? { ":pk": pk, ":prefix": skPrefix } : { ":pk": pk }
  };
  if (indexName) {
    params.IndexName = indexName;
    params.KeyConditionExpression = params.KeyConditionExpression.replace(/\bPK\b/g, indexName === "GSI1" ? "GSI1PK" : "GSI2PK").replace(/\bSK\b/g, indexName === "GSI1" ? "GSI1SK" : "GSI2SK");
  }
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}
async function queryGsi1(gsi1pk, gsi1skPrefix = null) {
  const params = {
    TableName: table(),
    IndexName: "GSI1",
    KeyConditionExpression: gsi1skPrefix ? "GSI1PK = :pk AND begins_with(GSI1SK, :prefix)" : "GSI1PK = :pk",
    ExpressionAttributeValues: gsi1skPrefix ? { ":pk": gsi1pk, ":prefix": gsi1skPrefix } : { ":pk": gsi1pk }
  };
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}

// shared/eventbridge.js
var import_client_eventbridge = require("@aws-sdk/client-eventbridge");
var eb = new import_client_eventbridge.EventBridgeClient({ region: process.env.AWS_REGION ?? "eu-west-2" });
var FIRE_LAMBDA_ARN = process.env.REMINDER_FIRE_LAMBDA_ARN;
var TARGET_ID = "ReminderFireTarget";
async function deleteRule(ruleName) {
  try {
    await eb.send(new import_client_eventbridge.RemoveTargetsCommand({ Rule: ruleName, Ids: [TARGET_ID] }));
    await eb.send(new import_client_eventbridge.DeleteRuleCommand({ Name: ruleName }));
  } catch (err) {
    if (err.name !== "ResourceNotFoundException") throw err;
  }
}

// wiedoethet-reminder-fire/index.js
var WHATSAPP_API = "https://graph.facebook.com/v19.0";
async function sendWhatsApp(phoneNumber, messageText) {
  const phoneId = process.env.WHATSAPP_PHONE_ID;
  const token = process.env.WHATSAPP_TOKEN;
  if (!phoneId || !token) throw new Error("WHATSAPP_PHONE_ID or WHATSAPP_TOKEN env var is not set");
  const res = await fetch(`${WHATSAPP_API}/${phoneId}/messages`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: phoneNumber,
      type: "text",
      text: { body: messageText }
    })
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(`WhatsApp API error ${res.status}: ${JSON.stringify(body)}`);
  }
  return res.json();
}
async function groupHasUnmetMinimums(groupId) {
  const taskItems = await queryByPk(`GROUP#${groupId}`, "TASK#");
  const checks = await Promise.all(
    taskItems.map(async (task) => {
      if (!task.maxClaims) return false;
      const claims = await queryByPk(`TASK#${task.id}`, "CLAIM#");
      return claims.length < task.maxClaims;
    })
  );
  return checks.some(Boolean);
}
async function taskHasUnmetMinimum(taskId, groupId) {
  const taskItems = await queryByPk(`GROUP#${groupId}`, "TASK#");
  const task = taskItems.find((t) => t.id === taskId);
  if (!task || !task.maxClaims) return false;
  const claims = await queryByPk(`TASK#${taskId}`, "CLAIM#");
  return claims.length < task.maxClaims;
}
var handler = async (event) => {
  process.env.TABLE_NAME = process.env.TABLE_NAME ?? "wdh-main";
  const { ruleName } = event;
  if (!ruleName) {
    console.error("reminder-fire: missing ruleName in event payload", event);
    return;
  }
  const [reminder] = await queryGsi1(`RULE#${ruleName}`);
  if (!reminder) {
    console.warn(`reminder-fire: no reminder found for rule ${ruleName} \u2014 already cancelled`);
    return;
  }
  if (reminder.status !== "scheduled") {
    console.warn(`reminder-fire: reminder ${ruleName} has status "${reminder.status}" \u2014 skipping`);
    await deleteRule(ruleName);
    return;
  }
  const { scope, scopeId, groupId, initiatorId } = reminder;
  try {
    const group = await getItem(`GROUP#${groupId}`, "METADATA");
    if (!group) {
      console.warn(`reminder-fire: group ${groupId} not found \u2014 aborting`);
      await updateItem(`REMINDER#${scope}#${scopeId}`, "REMINDER", { status: "failed" });
      await deleteRule(ruleName);
      return;
    }
    let shouldSend;
    if (scope === "group") {
      shouldSend = await groupHasUnmetMinimums(groupId);
    } else {
      shouldSend = await taskHasUnmetMinimum(scopeId, groupId);
    }
    if (!shouldSend) {
      console.warn(`reminder-fire: all minimums met for ${scope} ${scopeId} \u2014 no message sent`);
      await updateItem(`REMINDER#${scope}#${scopeId}`, "REMINDER", { status: "sent" });
      await deleteRule(ruleName);
      return;
    }
    const initiator = await getItem(`USER#${initiatorId}`, "PROFILE");
    if (!initiator?.phoneNumber) {
      console.warn(`reminder-fire: initiator ${initiatorId} has no phone number \u2014 aborting`);
      await updateItem(`REMINDER#${scope}#${scopeId}`, "REMINDER", { status: "failed" });
      await deleteRule(ruleName);
      return;
    }
    const shareUrl = `https://wiedoethet.nl/g/${group.shareToken}`;
    const messageText = `Herinnering: je groep "${group.name}" heeft nog niet genoeg deelnemers voor alle taken.
Deel de link opnieuw om iedereen te laten meedoen:
${shareUrl}`;
    await sendWhatsApp(initiator.phoneNumber, messageText);
    await updateItem(`REMINDER#${scope}#${scopeId}`, "REMINDER", { status: "sent" });
    console.warn(`reminder-fire: WhatsApp sent successfully for ${scope} ${scopeId}`);
  } catch (err) {
    console.error(`reminder-fire: error processing ${ruleName}`, err);
    await updateItem(`REMINDER#${scope}#${scopeId}`, "REMINDER", { status: "failed" });
  } finally {
    await deleteRule(ruleName);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
