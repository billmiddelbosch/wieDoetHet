var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// wiedoethet-whatsapp/index.js
var index_exports = {};
__export(index_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(index_exports);
var import_node_crypto2 = require("node:crypto");

// shared/http.js
var CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS"
};
function ok(data) {
  return { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify(data) };
}
function badRequest(message = "Ongeldig verzoek") {
  return { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function unauthorized(message = "Niet ingelogd") {
  return { statusCode: 401, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function forbidden(message = "Geen toegang") {
  return { statusCode: 403, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function notFound(message = "Niet gevonden") {
  return { statusCode: 404, headers: CORS_HEADERS, body: JSON.stringify({ message }) };
}
function serverError(err) {
  console.error(err);
  return {
    statusCode: 500,
    headers: CORS_HEADERS,
    body: JSON.stringify({ message: "Interne serverfout" })
  };
}
function parseBody(event) {
  try {
    return event.body ? JSON.parse(event.body) : {};
  } catch {
    return {};
  }
}
function extractBearer(event) {
  const auth = event.headers?.Authorization ?? event.headers?.authorization ?? "";
  const token = auth.replace(/^Bearer\s+/i, "");
  return token || null;
}

// shared/jwt.js
var import_node_crypto = require("node:crypto");
var SECRET = process.env.JWT_SECRET;
var EXPIRES_SEC = Number(process.env.JWT_EXPIRES_SEC ?? 2592e3);
function b64urlDecode(str) {
  return Buffer.from(str, "base64url").toString("utf8");
}
function sign(header, body) {
  return (0, import_node_crypto.createHmac)("sha256", SECRET).update(`${header}.${body}`).digest("base64url");
}
function verifyJwt(token) {
  if (!SECRET) throw new Error("JWT_SECRET env var is not set");
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Malformed token");
  const [header, body, sig] = parts;
  const expected = sign(header, body);
  if (sig.length !== expected.length) throw new Error("Invalid signature");
  let diff = 0;
  for (let i = 0; i < sig.length; i++) diff |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
  if (diff !== 0) throw new Error("Invalid signature");
  const payload = JSON.parse(b64urlDecode(body));
  if (payload.exp < Math.floor(Date.now() / 1e3)) throw new Error("Token expired");
  return payload;
}

// shared/db.js
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var client = new import_client_dynamodb.DynamoDBClient({});
var ddb = import_lib_dynamodb.DynamoDBDocumentClient.from(client, {
  marshallOptions: { removeUndefinedValues: true }
});
var table = () => process.env.TABLE_NAME ?? "wdh-main";
async function getItem(pk, sk) {
  const { Item } = await ddb.send(new import_lib_dynamodb.GetCommand({ TableName: table(), Key: { PK: pk, SK: sk } }));
  return Item ?? null;
}
async function putItem(item) {
  await ddb.send(new import_lib_dynamodb.PutCommand({ TableName: table(), Item: item }));
  return item;
}
async function queryByPk(pk, skPrefix = null, indexName = null) {
  const params = {
    TableName: table(),
    KeyConditionExpression: skPrefix ? "PK = :pk AND begins_with(SK, :prefix)" : "PK = :pk",
    ExpressionAttributeValues: skPrefix ? { ":pk": pk, ":prefix": skPrefix } : { ":pk": pk }
  };
  if (indexName) {
    params.IndexName = indexName;
    params.KeyConditionExpression = params.KeyConditionExpression.replace(/\bPK\b/g, indexName === "GSI1" ? "GSI1PK" : "GSI2PK").replace(/\bSK\b/g, indexName === "GSI1" ? "GSI1SK" : "GSI2SK");
  }
  const { Items } = await ddb.send(new import_lib_dynamodb.QueryCommand(params));
  return Items ?? [];
}

// wiedoethet-whatsapp/index.js
var META_API_BASE = "https://graph.facebook.com/v20.0";
var ALWAYS_200 = { statusCode: 200, headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }, body: "{}" };
async function sendPoll(event) {
  const user = requireAuth(event);
  if (!user) return unauthorized();
  const { groupId } = event.pathParameters ?? {};
  const group = await getItem(`GROUP#${groupId}`, "METADATA");
  if (!group) return notFound("Groep niet gevonden");
  if (group.initiatorId !== user.sub) return forbidden();
  const { to, tasks } = parseBody(event);
  if (!to) return badRequest("Telefoonnummer is verplicht");
  if (!tasks?.length) return badRequest("Geen taken opgegeven");
  if (tasks.length > 10) return badRequest("Te veel taken \u2014 splits de groep in twee groepen");
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  const accessToken = process.env.WHATSAPP_ACCESS_TOKEN;
  if (!phoneNumberId || !accessToken) return serverError(new Error("WhatsApp niet geconfigureerd"));
  const message = tasks.length <= 3 ? buildButtonMessage(to, group.name, groupId, tasks) : buildListMessage(to, group.name, groupId, tasks);
  const res = await fetch(`${META_API_BASE}/${phoneNumberId}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
    body: JSON.stringify(message)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    console.error("WhatsApp API error", err);
    return {
      statusCode: res.status,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ message: err?.error?.message ?? "WhatsApp fout" })
    };
  }
  return ok({ sent: true });
}
function buildButtonMessage(to, groupName, groupId, tasks) {
  return {
    messaging_product: "whatsapp",
    to,
    type: "interactive",
    interactive: {
      type: "button",
      body: { text: `Wie doet wat voor "${groupName}"?

Kies de taak die jij wilt doen:` },
      action: {
        buttons: tasks.map((t) => ({
          type: "reply",
          reply: {
            id: `${groupId}:${t.id}`,
            title: t.title.slice(0, 20)
          }
        }))
      }
    }
  };
}
function buildListMessage(to, groupName, groupId, tasks) {
  return {
    messaging_product: "whatsapp",
    to,
    type: "interactive",
    interactive: {
      type: "list",
      header: { type: "text", text: groupName },
      body: { text: "Kies de taak die jij wilt doen:" },
      footer: { text: "wieDoetHet" },
      action: {
        button: "Kies een taak",
        sections: [{
          title: "Taken",
          rows: tasks.map((t) => ({
            id: `${groupId}:${t.id}`,
            title: t.title.slice(0, 24),
            description: (t.description ?? "").slice(0, 72)
          }))
        }]
      }
    }
  };
}
function verifyWebhook(event) {
  const params = event.queryStringParameters ?? {};
  const mode = params["hub.mode"];
  const token = params["hub.verify_token"];
  const challenge = params["hub.challenge"];
  if (mode === "subscribe" && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    return { statusCode: 200, headers: { "Content-Type": "text/plain" }, body: challenge };
  }
  return { statusCode: 403, headers: {}, body: "Forbidden" };
}
async function handleWebhook(event) {
  const appSecret = process.env.WHATSAPP_APP_SECRET;
  if (appSecret) {
    const sig = event.headers?.["X-Hub-Signature-256"] ?? event.headers?.["x-hub-signature-256"] ?? "";
    const expected = "sha256=" + (0, import_node_crypto2.createHmac)("sha256", appSecret).update(event.body ?? "").digest("hex");
    if (sig !== expected) {
      console.warn("Invalid webhook signature");
      return ALWAYS_200;
    }
  }
  let payload;
  try {
    payload = JSON.parse(event.body ?? "{}");
  } catch {
    return ALWAYS_200;
  }
  const message = payload.entry?.[0]?.changes?.[0]?.value?.messages?.[0];
  const contacts = payload.entry?.[0]?.changes?.[0]?.value?.contacts ?? [];
  if (!message || message.type !== "interactive") return ALWAYS_200;
  const interactiveType = message.interactive?.type;
  const replyId = interactiveType === "button_reply" ? message.interactive.button_reply?.id : interactiveType === "list_reply" ? message.interactive.list_reply?.id : null;
  if (!replyId) return ALWAYS_200;
  const [groupId, taskId] = replyId.split(":");
  if (!groupId || !taskId) return ALWAYS_200;
  const from = message.from;
  const displayName = contacts.find((c) => c.wa_id === from)?.profile?.name ?? from;
  const taskItems = await queryByPk(`GROUP#${groupId}`, "TASK#");
  const task = taskItems.find((t) => t.id === taskId);
  if (!task) return ALWAYS_200;
  const existingClaims = await queryByPk(`TASK#${taskId}`, "CLAIM#");
  if (existingClaims.some((c) => c.sessionId === from)) return ALWAYS_200;
  if (task.maxClaims !== null && existingClaims.length >= task.maxClaims) return ALWAYS_200;
  const id = (0, import_node_crypto2.randomUUID)();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  await putItem({
    PK: `TASK#${taskId}`,
    SK: `CLAIM#${id}`,
    GSI1PK: `GCLAIM#${groupId}`,
    GSI1SK: now,
    id,
    groupId,
    taskId,
    userId: null,
    anonymousName: displayName,
    sessionId: from,
    claimedAt: now
  });
  return ALWAYS_200;
}
function requireAuth(event) {
  const token = extractBearer(event);
  if (!token) return null;
  try {
    return verifyJwt(token);
  } catch {
    return null;
  }
}
var handler = async (event) => {
  process.env.TABLE_NAME = event.stageVariables?.tableName ?? process.env.TABLE_NAME ?? "wdh-main";
  try {
    const method = event.httpMethod;
    const path = event.path?.replace(/\/$/, "");
    if (method === "OPTIONS") return {
      statusCode: 204,
      headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type,Authorization", "Access-Control-Allow-Methods": "GET,POST,OPTIONS" },
      body: ""
    };
    if (method === "GET" && path === "/webhook/whatsapp") return verifyWebhook(event);
    if (method === "POST" && path === "/webhook/whatsapp") return await handleWebhook(event);
    if (method === "POST" && /^\/groups\/[^/]+\/whatsapp-poll$/.test(path)) return await sendPoll(event);
    return { statusCode: 404, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: "Route niet gevonden" }) };
  } catch (err) {
    return serverError(err);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
